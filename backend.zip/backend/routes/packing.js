import { Router } from 'express';
import multer from 'multer';
import * as XLSX from 'xlsx';
import { getDb, logAction } from '../database.js';
import { getMoySkladService } from '../services/moysklad.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });

// ===== API для справочников МойСклад =====

// Получение организаций
router.get('/moysklad/organizations', async (req, res) => {
  try {
    const moysklad = getMoySkladService();
    const organizations = await moysklad.getOrganizations();
    res.json(organizations);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Получение складов
router.get('/moysklad/stores', async (req, res) => {
  try {
    const moysklad = getMoySkladService();
    const stores = await moysklad.getStores();
    res.json(stores);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Получение контрагентов
router.get('/moysklad/counterparties', async (req, res) => {
  try {
    const moysklad = getMoySkladService();
    const { search } = req.query;
    const counterparties = await moysklad.getCounterparties(search);
    res.json(counterparties);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Сохранение настроек МойСклад
router.post('/moysklad/settings', async (req, res) => {
  try {
    const db = await getDb();
    const { organizationId, storeId } = req.body;
    
    // Создаём таблицу настроек если её нет
    db.exec(`
      CREATE TABLE IF NOT EXISTS app_settings (
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at TEXT DEFAULT (datetime('now'))
      )
    `);
    
    if (organizationId) {
      db.prepare(`INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES ('moysklad_organization_id', ?, datetime('now'))`).run(organizationId);
    }
    if (storeId) {
      db.prepare(`INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES ('moysklad_store_id', ?, datetime('now'))`).run(storeId);
    }
    
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Получение настроек МойСклад
router.get('/moysklad/settings', async (req, res) => {
  try {
    const db = await getDb();
    
    // Создаём таблицу если её нет
    db.exec(`
      CREATE TABLE IF NOT EXISTS app_settings (
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at TEXT DEFAULT (datetime('now'))
      )
    `);
    
    const orgId = db.prepare(`SELECT value FROM app_settings WHERE key = 'moysklad_organization_id'`).get();
    const storeId = db.prepare(`SELECT value FROM app_settings WHERE key = 'moysklad_store_id'`).get();
    
    res.json({
      organizationId: orgId?.value || null,
      storeId: storeId?.value || null
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const rackOrderList = [
  41, 42, 37, 38, 39, 40, 52, 51, 50, 49,
  32, 36, 31, 35, 30, 34, 29, 33, 28,
  23, 18, 19, 24, 20, 25, 21, 26, 22, 27,
  48, 47, 46,
  12, 17, 11, 16, 10, 15, 9, 14, 8, 13,
  1, 2, 3, 4, 5, 6, 7, 45, 44, 43
];

const parseCellAddress = (addr) => {
  if (!addr) return { rack: null, shelf: null, cell: null };
  const s = String(addr).trim();

  const rackMatch = s.match(/стел+аж\.?\s*(\d+)/i);
  const shelfMatch = s.match(/полк(?:а|и|\.?)\s*(\d+)/i);
  const cellMatch = s.match(/яч(?:ейк\w*|\.?)\s*([A-Za-zА-Яа-я0-9]+)/i);

  const rack = rackMatch ? Number(rackMatch[1]) : null;
  const shelf = shelfMatch ? Number(shelfMatch[1]) : null;
  const cell = cellMatch ? String(cellMatch[1]).toUpperCase() : null;

  return { rack, shelf, cell };
};

const sortByRoute = (a, b) => {
  const ar = a.rack ?? null;
  const br = b.rack ?? null;

  const aIndex = ar !== null ? rackOrderList.indexOf(ar) : -1;
  const bIndex = br !== null ? rackOrderList.indexOf(br) : -1;

  if (aIndex !== bIndex) {
    if (aIndex === -1) return 1;
    if (bIndex === -1) return -1;
    return aIndex - bIndex;
  }

  const ashelf = a.shelf ?? 9999;
  const bshelf = b.shelf ?? 9999;
  if (ashelf !== bshelf) return ashelf - bshelf;

  const acell = a.cell ?? '';
  const bcell = b.cell ?? '';
  return acell.localeCompare(bcell);
};

// Получение списка задач
router.get('/tasks', async (req, res) => {
  try {
    const db = await getDb();
    const tasks = db.prepare(`
      SELECT t.*,
        (SELECT COUNT(*) FROM packing_task_items WHERE task_id = t.id) as items_count,
        (SELECT SUM(planned_qty) FROM packing_task_items WHERE task_id = t.id) as total_items,
        (SELECT SUM(scanned_qty) FROM packing_task_items WHERE task_id = t.id) as scanned_items
      FROM packing_tasks t
      ORDER BY t.created_at DESC
    `).all();

    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Получение задачи с деталями
router.get('/tasks/:id', async (req, res) => {
  try {
    const db = await getDb();
    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(req.params.id);
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }

    const items = db.prepare(`
      SELECT pti.*, p.name, p.barcode, p.article, p.image_url, p.stock, p.cell_address,
             p.requires_marking, p.meta_href, p.price
      FROM packing_task_items pti
      JOIN products p ON p.id = pti.product_id
      WHERE pti.task_id = ?
      ORDER BY p.cell_address, p.name
    `).all(req.params.id);
    
    // Добавляем все штрих-коды товара (для фильтрации по контрагенту)
    for (const item of items) {
      const allBarcodes = db.prepare(`
        SELECT barcode, barcode_type, pack_name FROM product_barcodes WHERE product_id = ?
      `).all(item.product_id);
      
      // Собираем все штрих-коды: основной + дополнительные
      const barcodes = [item.barcode, ...allBarcodes.map(b => b.barcode)].filter(Boolean);
      item.all_barcodes = barcodes.join(',');
      
      // Ищем OZN штрих-код (из упаковки Ozon)
      // Сначала ищем по названию упаковки, потом по формату штрих-кода
      const oznPack = allBarcodes.find(b => 
        (b.pack_name && (b.pack_name.toLowerCase().includes('ozon') || b.pack_name.toLowerCase().includes('озон'))) ||
        (b.barcode && b.barcode.toUpperCase().startsWith('OZN'))
      );
      item.ozn_barcode = oznPack?.barcode || barcodes.find(b => b.toUpperCase().startsWith('OZN')) || '';
      
      // Ищем EAN-13 штрих-код (из упаковки Вайлдберриз или просто EAN13)
      // Сначала ищем по названию упаковки, потом по формату
      const wbPack = allBarcodes.find(b => 
        (b.pack_name && (b.pack_name.toLowerCase().includes('wildberries') || b.pack_name.toLowerCase().includes('вайлдберри'))) ||
        (b.barcode_type === 'EAN13')
      );
      item.ean13_barcode = wbPack?.barcode || barcodes.find(b => /^\d{13}$/.test(b)) || '';
    }

    const noStockItems = items.filter((i) => (i.stock || 0) <= 0);
    const visibleItems = items.filter((i) => (i.stock || 0) > 0);

    const totalPlanned = visibleItems.reduce((s, i) => s + i.planned_qty, 0);
    const totalScanned = visibleItems.reduce((s, i) => s + i.scanned_qty, 0);

    res.json({
      task: { ...task, total_items: totalPlanned, scanned_items: totalScanned, no_stock_items: noStockItems.length },
      items: visibleItems,
      noStockItems: noStockItems.length ? noStockItems : undefined
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Обновление названия задачи
router.put('/tasks/:id', async (req, res) => {
  try {
    const db = await getDb();
    const { name } = req.body;
    const taskId = req.params.id;
    
    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ error: 'Задача не найдена' });
    }
    
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Название не может быть пустым' });
    }
    
    db.prepare('UPDATE packing_tasks SET name = ? WHERE id = ?').run(name.trim(), taskId);
    
    await logAction('task_renamed', 'packing_task', taskId, { oldName: task.name, newName: name.trim() });
    
    res.json({ success: true, name: name.trim() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Загрузка Excel файла
router.post('/tasks/upload', upload.single('file'), async (req, res) => {
  try {
    const db = await getDb();

    if (!req.file) {
      return res.status(400).json({ error: 'Файл не загружен' });
    }
    
    // Получаем данные контрагента из body (если передано как FormData)
    const counterpartyId = req.body.counterpartyId || null;
    const counterpartyName = req.body.counterpartyName || null;

    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const data = XLSX.utils.sheet_to_json(sheet);

    if (data.length === 0) {
      return res.status(400).json({ error: 'Файл пустой' });
    }

    const items = [];
    const errors = [];
    const notFound = [];

    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      const barcode = row.Barcode || row.barcode || row['Баркод'] || row['ШтрихКод'] || row['штрихкод'] || row['Штрих-код'] || '';
      const sku = row.SKU || row.sku || row['Артикул'] || row['артикул'] || row.Article || row.article || '';
      const name = row.Name || row.name || row['Наименование'] || row['наименование'] || row['Товар'] || '';
      const quantity = Number(row.Quantity || row.quantity || row['Количество'] || row['количество'] || row.Qty || 1);

      if (!barcode && !sku && !name) continue;
      if (!quantity || quantity <= 0) continue;

      let product = null;
      if (barcode) {
        product = db.prepare(`
          SELECT p.* FROM products p
          LEFT JOIN product_barcodes pb ON pb.product_id = p.id
          WHERE p.barcode = ? OR pb.barcode = ? LIMIT 1
        `).get(String(barcode).trim(), String(barcode).trim());
      }
      if (!product && sku) {
        product = db.prepare('SELECT * FROM products WHERE sku = ? OR article = ?')
          .get(String(sku).trim(), String(sku).trim());
      }
      if (!product && name) {
        product = db.prepare('SELECT * FROM products WHERE LOWER(name) LIKE ?')
          .get(`%${String(name).toLowerCase().trim()}%`);
      }

      if (!product) {
        notFound.push({ row: i + 2, barcode, sku, name, quantity });
        continue;
      }

      const available = Number(product.stock || 0);
      if (!Number.isFinite(available) || available <= 0) {
        errors.push({ row: i + 2, barcode, sku, name, quantity, reason: 'no_stock' });
        continue;
      }
      
      // Пропускаем товары без ячейки - они недоступны для сборки
      if (!product.cell_address) {
        errors.push({ row: i + 2, barcode, sku, name, quantity, reason: 'no_cell', productName: product.name });
        continue;
      }

      const qty = Math.min(quantity, available);
      items.push({ product, quantity: qty, available });
    }

    if (items.length === 0) {
      return res.status(400).json({ error: 'Не найдено товаров с ячейками', notFound, skippedNoCell: errors.filter(e => e.reason === 'no_cell') });
    }

    const taskName = `Сборка ${new Date().toLocaleDateString('ru')} ${new Date().toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' })}`;
    const totalQty = items.reduce((sum, i) => sum + i.quantity, 0);

    const taskResult = db.prepare(`
      INSERT INTO packing_tasks (name, status, total_items, counterparty_id, counterparty_name) 
      VALUES (?, 'active', ?, ?, ?)
    `).run(taskName, totalQty, counterpartyId, counterpartyName);
    const taskId = taskResult.lastInsertRowid;

    const insertItem = db.prepare(`
      INSERT INTO packing_task_items (task_id, product_id, planned_qty, scanned_qty, requires_marking)
      VALUES (?, ?, ?, 0, ?)
    `);
    for (const item of items) {
      insertItem.run(taskId, item.product.id, item.quantity, item.product.requires_marking ? 1 : 0);
    }

    await logAction('packing_task_created', 'packing_task', taskId, { totalQuantity: totalQty, counterpartyId });

    // === Автоматическое создание документов в МойСклад ===
    let customerOrderId = null;
    let demandId = null;
    let moySkladError = null;

    if (counterpartyId) {
      try {
        // Получаем настройки
        const orgSetting = db.prepare(`SELECT value FROM app_settings WHERE key = 'moysklad_organization_id'`).get();
        const storeSetting = db.prepare(`SELECT value FROM app_settings WHERE key = 'moysklad_store_id'`).get();

        if (orgSetting?.value && storeSetting?.value) {
          const moysklad = getMoySkladService();

          // 1. Создаём Заказ покупателя
          const orderItems = items.map(i => ({
            quantity: i.quantity,
            meta_href: i.product.meta_href,
            price: i.product.price || 0
          }));

          const order = await moysklad.createCustomerOrder({
            name: `Заказ: ${taskName}`,
            items: orderItems,
            organizationId: orgSetting.value,
            counterpartyId: counterpartyId,
            storeId: storeSetting.value
          });
          customerOrderId = order.id;

          // 2. Создаём Отгрузку (НЕ проведённую) с информацией о ячейках
          // Ищем ячейки по cell_address через кэш (загруженный из getAllStoreSlots)
          const demandItems = [];
          let itemsWithSlot = 0;
          let itemsWithoutSlot = 0;
          
          for (const i of items) {
            // Пропускаем товары без cell_address
            if (!i.product.cell_address) {
              itemsWithoutSlot++;
              console.log(`Товар без ячейки (cell_address): ${i.product.name}`);
              continue;
            }
            
            // Ищем ячейку по названию через кэш
            const slot = await moysklad.getSlotByName(i.product.cell_address);
            
            if (slot && slot.id) {
              // Формируем slot_href
              const slotHref = slot.href || `https://api.moysklad.ru/api/remap/1.2/entity/slot/${slot.id}`;
              
              demandItems.push({
                quantity: i.quantity,
                meta_href: i.product.meta_href,
                price: i.product.price || 0,
                slot_href: slotHref
              });
              itemsWithSlot++;
              console.log(`✓ ${i.product.name} -> ${i.product.cell_address} (slot: ${slot.id.substring(0,8)}...)`);
            } else {
              itemsWithoutSlot++;
              console.log(`✗ Ячейка не найдена: ${i.product.cell_address} для ${i.product.name}`);
            }
          }
          
          console.log(`Итого: ${itemsWithSlot} товаров с ячейками, ${itemsWithoutSlot} без ячеек`);

          // Создаём отгрузку только если есть товары с ячейками
          if (demandItems.length > 0) {
            const demand = await moysklad.createDemand({
              name: `Отгрузка: ${taskName}`,
              items: demandItems,
              organizationId: orgSetting.value,
              counterpartyId: counterpartyId,
              storeId: storeSetting.value,
              customerOrderId: customerOrderId,
              applicable: false // НЕ проведена - остатки не списываются
            });
            demandId = demand.id;

            // Сохраняем ID документов в задаче
            db.prepare(`UPDATE packing_tasks SET customer_order_id = ?, demand_id = ? WHERE id = ?`)
              .run(customerOrderId, demandId, taskId);

            console.log(`Созданы документы: Заказ ${customerOrderId}, Отгрузка ${demandId}`);
          } else {
            // Сохраняем только заказ
            db.prepare(`UPDATE packing_tasks SET customer_order_id = ? WHERE id = ?`)
              .run(customerOrderId, taskId);
            console.log(`Создан только заказ ${customerOrderId} (нет товаров с ячейками)`);
            moySkladError = 'Отгрузка не создана: нет товаров с найденными ячейками';
          }
        } else {
          moySkladError = 'Не настроены организация или склад';
        }
      } catch (err) {
        console.error('MoySklad documents creation error:', err.message);
        moySkladError = err.message;
      }
    }

    const skippedNoStock = errors.filter((e) => e.reason === 'no_stock');
    res.json({
      success: true,
      taskId,
      created: items.length,
      totalQuantity: totalQty,
      notFound: notFound.length > 0 ? notFound : undefined,
      skippedNoStock: skippedNoStock.length > 0 ? skippedNoStock : undefined,
      skippedNoCell: errors.filter(e => e.reason === 'no_cell'),
      customerOrderId,
      demandId,
      moySkladError
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Ошибка загрузки', message: error.message });
  }
});

// Маршрутный лист
router.get('/tasks/:id/route-sheet', async (req, res) => {
  try {
    const db = await getDb();
    const taskId = req.params.id;

    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task) return res.status(404).json({ error: 'Task not found' });

    const items = db.prepare(`
      SELECT pti.id, pti.product_id, pti.planned_qty, pti.scanned_qty,
             p.name, p.article, p.barcode, p.stock, p.cell_address
      FROM packing_task_items pti
      JOIN products p ON p.id = pti.product_id
      WHERE pti.task_id = ?
    `).all(taskId);

    const withLoc = items.map((it) => {
      const loc = parseCellAddress(it.cell_address);
      return { ...it, ...loc };
    });

    const available = withLoc.filter((i) => (i.stock ?? 0) > 0 && i.planned_qty > 0);
    const availableWithShelf = available.filter((i) => i.rack !== null && i.shelf !== null && i.cell !== null);
    const hangingStock = available.filter((i) => i.rack === null || i.shelf === null || i.cell === null);
    availableWithShelf.sort(sortByRoute);

    const zonesMap = new Map();
    for (const it of availableWithShelf) {
      const rack = it.rack;
      const qtyToCollect = Math.max((it.planned_qty || 0) - (it.scanned_qty || 0), 0);
      if (qtyToCollect <= 0) continue;
      if (!zonesMap.has(rack)) zonesMap.set(rack, []);
      zonesMap.get(rack).push({
        id: it.id,
        product_id: it.product_id,
        name: it.name,
        barcode: it.barcode,
        cell_address: it.cell_address,
        qty_to_collect: qtyToCollect,
        planned_qty: it.planned_qty,
        scanned_qty: it.scanned_qty,
        stock: it.stock
      });
    }

    const orderedRacks = Array.from(zonesMap.keys()).sort((a, b) => {
      const aIndex = rackOrderList.indexOf(a);
      const bIndex = rackOrderList.indexOf(b);
      if (aIndex === -1 && bIndex === -1) return a - b;
      if (aIndex === -1) return 1;
      if (bIndex === -1) return -1;
      return aIndex - bIndex;
    });

    const zones = orderedRacks.map((rack) => ({
      rack,
      items: zonesMap.get(rack)
    }));

    const noStock = withLoc.filter((i) => (i.stock ?? 0) <= 0 && i.planned_qty > 0);
    const totalToCollect = availableWithShelf.reduce((sum, i) => sum + Math.max((i.planned_qty || 0) - (i.scanned_qty || 0), 0), 0);

    res.json({
      task,
      zones,
      available: availableWithShelf.length,
      totalToCollect,
      noStock,
      noStockCount: noStock.length,
      hangingStock
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== КОРОБА =====

// Получение коробов задачи
router.get('/tasks/:id/boxes', async (req, res) => {
  try {
    const db = await getDb();
    const taskId = req.params.id;
    
    const boxes = db.prepare(`
      SELECT b.*, 
        (SELECT COUNT(*) FROM box_items WHERE box_id = b.id) as items_count,
        (SELECT SUM(quantity) FROM box_items WHERE box_id = b.id) as total_qty
      FROM boxes b
      WHERE b.task_id = ?
      ORDER BY b.number ASC
    `).all(taskId);
    
    res.json({ boxes });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Создание нового короба
router.post('/tasks/:id/boxes', async (req, res) => {
  try {
    const db = await getDb();
    const taskId = req.params.id;
    
    // Проверяем существование задачи
    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ error: 'Задача не найдена' });
    }
    
    if (task.status !== 'active') {
      return res.status(400).json({ error: 'Задача не активна' });
    }
    
    // Получаем максимальный номер короба
    const maxBox = db.prepare('SELECT MAX(number) as maxNum FROM boxes WHERE task_id = ?').get(taskId);
    const nextNumber = (maxBox?.maxNum || 0) + 1;
    
    // Создаём короб
    const result = db.prepare(`
      INSERT INTO boxes (task_id, number, status, created_at)
      VALUES (?, ?, 'open', datetime('now'))
    `).run(taskId, nextNumber);
    
    const boxId = result.lastInsertRowid;
    
    await logAction('box_created', 'box', boxId, { taskId, number: nextNumber });
    
    res.json({ 
      success: true, 
      box: { id: boxId, number: nextNumber, status: 'open', task_id: taskId }
    });
  } catch (err) {
    console.error('Create box error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Обновление штрих-кода короба от маркетплейса
router.put('/tasks/:id/boxes/:boxId', async (req, res) => {
  try {
    const db = await getDb();
    const { id: taskId, boxId } = req.params;
    const { marketplace_barcode } = req.body;
    
    const box = db.prepare('SELECT * FROM boxes WHERE id = ? AND task_id = ?').get(boxId, taskId);
    if (!box) {
      return res.status(404).json({ error: 'Короб не найден' });
    }
    
    db.prepare('UPDATE boxes SET marketplace_barcode = ? WHERE id = ?').run(marketplace_barcode || null, boxId);
    
    await logAction('box_barcode_updated', 'box', boxId, { taskId, marketplace_barcode });
    
    res.json({ success: true, message: 'Штрих-код короба обновлён' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Закрытие короба
router.post('/tasks/:id/boxes/:boxId/close', async (req, res) => {
  try {
    const db = await getDb();
    const { id: taskId, boxId } = req.params;
    
    const box = db.prepare('SELECT * FROM boxes WHERE id = ? AND task_id = ?').get(boxId, taskId);
    if (!box) {
      return res.status(404).json({ error: 'Короб не найден' });
    }
    
    if (box.status === 'closed') {
      return res.status(400).json({ error: 'Короб уже закрыт' });
    }
    
    // Проверяем есть ли товары в коробе
    const itemsCount = db.prepare('SELECT COUNT(*) as cnt FROM box_items WHERE box_id = ?').get(boxId);
    if (!itemsCount || itemsCount.cnt === 0) {
      return res.status(400).json({ error: 'Нельзя закрыть пустой короб' });
    }
    
    db.prepare('UPDATE boxes SET status = ? WHERE id = ?').run('closed', boxId);
    
    await logAction('box_closed', 'box', boxId, { taskId, number: box.number });
    
    res.json({ success: true, message: `Короб #${box.number} закрыт` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Открытие закрытого короба (для редактирования)
router.post('/tasks/:id/boxes/:boxId/reopen', async (req, res) => {
  try {
    const db = await getDb();
    const { id: taskId, boxId } = req.params;
    
    const box = db.prepare('SELECT * FROM boxes WHERE id = ? AND task_id = ?').get(boxId, taskId);
    if (!box) {
      return res.status(404).json({ error: 'Короб не найден' });
    }
    
    db.prepare('UPDATE boxes SET status = ? WHERE id = ?').run('open', boxId);
    
    await logAction('box_reopened', 'box', boxId, { taskId, number: box.number });
    
    res.json({ success: true, message: `Короб #${box.number} открыт для редактирования` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Получение содержимого короба
router.get('/tasks/:id/boxes/:boxId/items', async (req, res) => {
  try {
    const db = await getDb();
    const { id: taskId, boxId } = req.params;
    
    const box = db.prepare('SELECT * FROM boxes WHERE id = ? AND task_id = ?').get(boxId, taskId);
    if (!box) {
      return res.status(404).json({ error: 'Короб не найден' });
    }
    
    // Получаем товары в коробе с группировкой по product_id
    const items = db.prepare(`
      SELECT 
        bi.product_id,
        p.name,
        p.barcode,
        p.article,
        SUM(bi.quantity) as quantity,
        COUNT(bi.id) as scans_count,
        GROUP_CONCAT(bi.chestny_znak) as marking_codes
      FROM box_items bi
      JOIN products p ON p.id = bi.product_id
      WHERE bi.box_id = ?
      GROUP BY bi.product_id
      ORDER BY p.name
    `).all(boxId);
    
    // Также получаем все записи для детализации (если нужны коды маркировки)
    const details = db.prepare(`
      SELECT bi.*, p.name, p.barcode
      FROM box_items bi
      JOIN products p ON p.id = bi.product_id
      WHERE bi.box_id = ?
      ORDER BY bi.scanned_at DESC
    `).all(boxId);
    
    res.json({ 
      box,
      items,
      details,
      totalItems: items.reduce((sum, i) => sum + i.quantity, 0)
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Обновление количества товара в коробе
router.put('/tasks/:id/boxes/:boxId/items/:productId', async (req, res) => {
  try {
    const db = await getDb();
    const { id: taskId, boxId, productId } = req.params;
    const { quantity } = req.body;
    
    const box = db.prepare('SELECT * FROM boxes WHERE id = ? AND task_id = ?').get(boxId, taskId);
    if (!box) {
      return res.status(404).json({ error: 'Короб не найден' });
    }
    
    // Получаем текущее количество товара в коробе
    const currentItems = db.prepare(`
      SELECT SUM(quantity) as total FROM box_items WHERE box_id = ? AND product_id = ?
    `).get(boxId, productId);
    
    const currentQty = currentItems?.total || 0;
    const newQty = Math.max(0, parseInt(quantity) || 0);
    const diff = newQty - currentQty;
    
    if (diff === 0) {
      return res.json({ success: true, message: 'Количество не изменилось' });
    }
    
    if (newQty === 0) {
      // Удаляем все записи этого товара из короба
      db.prepare('DELETE FROM box_items WHERE box_id = ? AND product_id = ?').run(boxId, productId);
      
      // Уменьшаем scanned_qty в задаче
      db.prepare(`
        UPDATE packing_task_items 
        SET scanned_qty = MAX(0, scanned_qty - ?)
        WHERE task_id = ? AND product_id = ?
      `).run(currentQty, taskId, productId);
    } else if (diff > 0) {
      // Добавляем записи
      const insertStmt = db.prepare(`
        INSERT INTO box_items (box_id, product_id, quantity, scanned_at)
        VALUES (?, ?, 1, datetime('now'))
      `);
      for (let i = 0; i < diff; i++) {
        insertStmt.run(boxId, productId);
      }
      
      // Увеличиваем scanned_qty в задаче
      db.prepare(`
        UPDATE packing_task_items 
        SET scanned_qty = scanned_qty + ?
        WHERE task_id = ? AND product_id = ?
      `).run(diff, taskId, productId);
    } else {
      // Удаляем часть записей (без кода маркировки в первую очередь)
      const toDelete = Math.abs(diff);
      const itemsToDelete = db.prepare(`
        SELECT id FROM box_items 
        WHERE box_id = ? AND product_id = ?
        ORDER BY chestny_znak IS NOT NULL, scanned_at DESC
        LIMIT ?
      `).all(boxId, productId, toDelete);
      
      for (const item of itemsToDelete) {
        db.prepare('DELETE FROM box_items WHERE id = ?').run(item.id);
      }
      
      // Уменьшаем scanned_qty в задаче
      db.prepare(`
        UPDATE packing_task_items 
        SET scanned_qty = MAX(0, scanned_qty - ?)
        WHERE task_id = ? AND product_id = ?
      `).run(toDelete, taskId, productId);
    }
    
    await logAction('box_item_updated', 'box', boxId, { productId, oldQty: currentQty, newQty, diff });
    
    res.json({ success: true, message: `Количество изменено: ${currentQty} → ${newQty}` });
  } catch (err) {
    console.error('Update box item error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Удаление товара из короба
router.delete('/tasks/:id/boxes/:boxId/items/:productId', async (req, res) => {
  try {
    const db = await getDb();
    const { id: taskId, boxId, productId } = req.params;
    
    const box = db.prepare('SELECT * FROM boxes WHERE id = ? AND task_id = ?').get(boxId, taskId);
    if (!box) {
      return res.status(404).json({ error: 'Короб не найден' });
    }
    
    // Получаем количество удаляемого товара
    const currentItems = db.prepare(`
      SELECT SUM(quantity) as total FROM box_items WHERE box_id = ? AND product_id = ?
    `).get(boxId, productId);
    
    const deletedQty = currentItems?.total || 0;
    
    // Удаляем записи
    db.prepare('DELETE FROM box_items WHERE box_id = ? AND product_id = ?').run(boxId, productId);
    
    // Уменьшаем scanned_qty в задаче
    if (deletedQty > 0) {
      db.prepare(`
        UPDATE packing_task_items 
        SET scanned_qty = MAX(0, scanned_qty - ?)
        WHERE task_id = ? AND product_id = ?
      `).run(deletedQty, taskId, productId);
    }
    
    await logAction('box_item_deleted', 'box', boxId, { productId, deletedQty });
    
    res.json({ success: true, message: `Товар удалён из короба (${deletedQty} шт)` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Добавление товара в короб вручную
router.post('/tasks/:id/boxes/:boxId/items', async (req, res) => {
  try {
    const db = await getDb();
    const { id: taskId, boxId } = req.params;
    const { productId, quantity } = req.body;
    
    const box = db.prepare('SELECT * FROM boxes WHERE id = ? AND task_id = ?').get(boxId, taskId);
    if (!box) {
      return res.status(404).json({ error: 'Короб не найден' });
    }
    
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
    if (!product) {
      return res.status(404).json({ error: 'Товар не найден' });
    }
    
    const qty = Math.max(1, parseInt(quantity) || 1);
    
    // Добавляем записи
    const insertStmt = db.prepare(`
      INSERT INTO box_items (box_id, product_id, quantity, scanned_at)
      VALUES (?, ?, 1, datetime('now'))
    `);
    for (let i = 0; i < qty; i++) {
      insertStmt.run(boxId, productId);
    }
    
    // Проверяем есть ли этот товар в задаче
    const taskItem = db.prepare('SELECT * FROM packing_task_items WHERE task_id = ? AND product_id = ?')
      .get(taskId, productId);
    
    if (taskItem) {
      // Увеличиваем scanned_qty
      db.prepare(`
        UPDATE packing_task_items 
        SET scanned_qty = scanned_qty + ?
        WHERE task_id = ? AND product_id = ?
      `).run(qty, taskId, productId);
    }
    
    await logAction('box_item_added', 'box', boxId, { productId, quantity: qty });
    
    res.json({ success: true, message: `Добавлено ${qty} шт`, product: product.name });
  } catch (err) {
    console.error('Add box item error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ===== СКАНИРОВАНИЕ =====

// Сканирование товара
router.post('/tasks/:id/scan', async (req, res) => {
  try {
    const db = await getDb();
    const taskId = req.params.id;
    const { barcode, boxId, chestnyZnak } = req.body;
    
    if (!barcode) {
      return res.status(400).json({ error: 'Штрихкод не указан' });
    }
    
    // Проверяем задачу
    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ error: 'Задача не найдена' });
    }
    
    if (task.status !== 'active') {
      return res.status(400).json({ error: 'Задача не активна' });
    }
    
    // Ищем товар по штрихкоду
    let product = db.prepare(`
      SELECT p.* FROM products p
      LEFT JOIN product_barcodes pb ON pb.product_id = p.id
      WHERE p.barcode = ? OR pb.barcode = ?
      LIMIT 1
    `).get(barcode.trim(), barcode.trim());
    
    if (!product) {
      return res.status(404).json({ error: 'Товар не найден', barcode });
    }
    
    // Ищем позицию в задаче
    const taskItem = db.prepare(`
      SELECT * FROM packing_task_items 
      WHERE task_id = ? AND product_id = ?
    `).get(taskId, product.id);
    
    if (!taskItem) {
      return res.status(400).json({ error: 'Товар не входит в задачу', product: product.name });
    }
    
    // Проверяем не собрано ли уже всё
    if (taskItem.scanned_qty >= taskItem.planned_qty) {
      return res.status(400).json({ 
        error: 'Позиция уже полностью собрана', 
        product: product.name,
        scanned: taskItem.scanned_qty,
        quantity: taskItem.planned_qty
      });
    }
    
    // Проверяем требуется ли маркировка
    if (taskItem.requires_marking && !chestnyZnak) {
      return res.status(400).json({ 
        error: 'Требуется код маркировки', 
        requiresMarking: true,
        product: product.name 
      });
    }
    
    // Проверяем короб
    let actualBoxId = boxId;
    if (actualBoxId) {
      const box = db.prepare('SELECT * FROM boxes WHERE id = ? AND task_id = ?').get(actualBoxId, taskId);
      if (!box) {
        return res.status(400).json({ error: 'Короб не найден' });
      }
      if (box.status === 'closed') {
        return res.status(400).json({ error: 'Короб закрыт, выберите другой' });
      }
    }
    
    // Если код маркировки — проверяем уникальность
    if (chestnyZnak) {
      const existingMark = db.prepare('SELECT * FROM box_items WHERE chestny_znak = ?').get(chestnyZnak);
      if (existingMark) {
        return res.status(400).json({ error: 'Этот код маркировки уже отсканирован' });
      }
      
      // Защита от случайного сканирования штрихкода товара вместо кода маркировки
      // Код маркировки (DataMatrix) обычно длиннее 20 символов и содержит специальные символы
      // Штрихкоды товаров обычно 8-14 цифр (EAN-8, EAN-13, UPC)
      const cleanChestnyZnak = chestnyZnak.trim();
      
      // Проверяем не является ли введённый код штрихкодом какого-либо товара
      const isProductBarcode = db.prepare(`
        SELECT p.id, p.name FROM products p
        LEFT JOIN product_barcodes pb ON pb.product_id = p.id
        WHERE p.barcode = ? OR pb.barcode = ?
        LIMIT 1
      `).get(cleanChestnyZnak, cleanChestnyZnak);
      
      if (isProductBarcode) {
        return res.status(400).json({ 
          error: 'Отсканирован штрихкод товара, а не код маркировки!',
          hint: 'Отсканируйте DataMatrix код маркировки (Честный знак)',
          scannedProduct: isProductBarcode.name
        });
      }
      
      // Дополнительная проверка: код маркировки должен быть достаточно длинным
      // DataMatrix коды Честного знака обычно от 31 символа и больше
      if (cleanChestnyZnak.length < 20) {
        return res.status(400).json({ 
          error: 'Код маркировки слишком короткий',
          hint: 'Код маркировки (Честный знак) должен содержать минимум 20 символов',
          length: cleanChestnyZnak.length
        });
      }
    }
    
    // Увеличиваем счётчик отсканированных
    db.prepare(`
      UPDATE packing_task_items 
      SET scanned_qty = scanned_qty + 1 
      WHERE id = ?
    `).run(taskItem.id);
    
    // Добавляем в короб (если указан)
    if (actualBoxId) {
      db.prepare(`
        INSERT INTO box_items (box_id, product_id, quantity, chestny_znak, scanned_at)
        VALUES (?, ?, 1, ?, datetime('now'))
      `).run(actualBoxId, product.id, chestnyZnak || null);
    }
    
    // Получаем обновлённые данные
    const updatedItem = db.prepare('SELECT * FROM packing_task_items WHERE id = ?').get(taskItem.id);
    const isComplete = updatedItem.scanned_qty >= updatedItem.planned_qty;
    
    await logAction('item_scanned', 'packing_task_item', taskItem.id, { 
      taskId, 
      productId: product.id, 
      boxId: actualBoxId,
      chestnyZnak: chestnyZnak ? 'yes' : 'no'
    });
    
    res.json({
      success: true,
      product: product.name,
      scanned: updatedItem.scanned_qty,
      quantity: updatedItem.planned_qty,
      complete: isComplete
    });
  } catch (err) {
    console.error('Scan error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ===== ЗАВЕРШЕНИЕ ЗАДАЧИ =====

// Завершение задачи упаковки (создаёт отгрузку)
router.post('/tasks/:id/complete', async (req, res) => {
  try {
    const db = await getDb();
    const taskId = req.params.id;
    
    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ error: 'Задача не найдена' });
    }
    
    if (task.status !== 'active') {
      return res.status(400).json({ error: 'Задача уже завершена или отменена' });
    }
    
    // Проверяем что хоть что-то собрано
    const stats = db.prepare(`
      SELECT SUM(scanned_qty) as scanned, SUM(planned_qty) as planned
      FROM packing_task_items WHERE task_id = ?
    `).get(taskId);
    
    if (!stats || stats.scanned === 0) {
      return res.status(400).json({ error: 'Нельзя завершить задачу без собранных товаров' });
    }
    
    // Закрываем все открытые короба
    db.prepare(`UPDATE boxes SET status = 'closed' WHERE task_id = ? AND status = 'open'`).run(taskId);
    
    // Проводим отгрузку в МойСклад (списываем остатки)
    let demandApproved = false;
    let demandError = null;
    
    if (task.demand_id) {
      try {
        const moysklad = getMoySkladService();
        await moysklad.approveDemand(task.demand_id);
        demandApproved = true;
        console.log(`Отгрузка ${task.demand_id} проведена для задачи ${taskId}`);
      } catch (err) {
        console.error('Demand approval error:', err.message);
        demandError = err.message;
      }
    }
    
    // Завершаем задачу
    db.prepare(`
      UPDATE packing_tasks 
      SET status = 'completed', completed_at = datetime('now')
      WHERE id = ?
    `).run(taskId);
    
    await logAction('packing_task_completed', 'packing_task', taskId, { 
      scanned: stats.scanned, 
      planned: stats.planned,
      demandId: task.demand_id,
      demandApproved,
      demandError
    });
    
    res.json({ 
      success: true, 
      message: `Задача завершена. Собрано ${stats.scanned} из ${stats.planned} шт.${demandApproved ? ' Остатки списаны.' : ''}`,
      demandId: task.demand_id,
      demandApproved,
      demandError
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Генерация Excel файла с общим списком товаров
router.get('/tasks/:id/export/products', async (req, res) => {
  try {
    const db = await getDb();
    const taskId = req.params.id;
    
    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ error: 'Задача не найдена' });
    }
    
    // Получаем собранные товары
    const items = db.prepare(`
      SELECT pti.scanned_qty as quantity, p.article, p.name, p.barcode
      FROM packing_task_items pti
      JOIN products p ON p.id = pti.product_id
      WHERE pti.task_id = ? AND pti.scanned_qty > 0
      ORDER BY p.article
    `).all(taskId);
    
    // Формируем данные для Excel
    const data = items.map(item => ({
      'артикул': item.article || item.barcode || '',
      'имя (необязательно)': item.name || '',
      'количество': item.quantity
    }));
    
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Товары');
    
    // Устанавливаем ширину колонок
    worksheet['!cols'] = [
      { wch: 30 }, // артикул
      { wch: 50 }, // имя
      { wch: 12 }  // количество
    ];
    
    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    
    const filename = `products_${task.name.replace(/[^a-zA-Zа-яА-Я0-9]/g, '_')}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`);
    res.send(buffer);
    
  } catch (err) {
    console.error('Export products error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Генерация Excel файла с привязкой товаров к коробам (грузовым местам)
router.get('/tasks/:id/export/boxes', async (req, res) => {
  try {
    const db = await getDb();
    const taskId = req.params.id;
    
    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ error: 'Задача не найдена' });
    }
    
    // Получаем короба
    const boxes = db.prepare('SELECT * FROM boxes WHERE task_id = ? ORDER BY number').all(taskId);
    
    // Получаем товары по коробам
    const data = [];
    
    for (const box of boxes) {
      const boxItems = db.prepare(`
        SELECT bi.quantity, bi.product_id, p.barcode, p.article, p.name
        FROM box_items bi
        JOIN products p ON p.id = bi.product_id
        WHERE bi.box_id = ?
        ORDER BY p.article
      `).all(box.id);
      
      // Группируем по product_id
      const grouped = {};
      for (const item of boxItems) {
        const key = item.product_id;
        if (!grouped[key]) {
          grouped[key] = { ...item, quantity: 0 };
        }
        grouped[key].quantity += item.quantity;
      }
      
      // Используем marketplace_barcode если есть, иначе генерируем
      const boxBarcode = box.marketplace_barcode || `1000000000${String(taskId).padStart(6, '0')}${String(box.number).padStart(3, '0')}`;
      
      for (const item of Object.values(grouped)) {
        data.push({
          'ШК товара': item.barcode || '',
          'Артикул товара': item.article || '',
          'Кол-во товаров': item.quantity,
          'Зона размещения': 'Сортируемый товар',
          'Срок годности ДО в формате YYYY-MM-DD (не более 1 СГ на 1 SKU в 1 ГМ)': '',
          'ШК ГМ': boxBarcode,
          'Тип ГМ (не обязательно)': 'Коробка'
        });
      }
    }
    
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Грузовые места');
    
    // Устанавливаем ширину колонок
    worksheet['!cols'] = [
      { wch: 18 }, // ШК товара
      { wch: 40 }, // Артикул
      { wch: 15 }, // Кол-во
      { wch: 20 }, // Зона
      { wch: 55 }, // Срок годности
      { wch: 20 }, // ШК ГМ
      { wch: 22 }  // Тип ГМ
    ];
    
    const filename = `boxes_${task.name.replace(/[^a-zA-Zа-яА-Я0-9]/g, '_')}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`);
    
    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    res.send(buffer);
    
  } catch (err) {
    console.error('Export boxes error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Создание задачи вручную
router.post('/tasks', async (req, res) => {
  try {
    const db = await getDb();
    const { items } = req.body;
    
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Нет товаров для задачи' });
    }
    
    const taskName = `Сборка ${new Date().toLocaleDateString('ru')} ${new Date().toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' })}`;
    const totalQty = items.reduce((sum, i) => sum + (i.quantity || 0), 0);
    
    const taskResult = db.prepare(`
      INSERT INTO packing_tasks (name, status, total_items, source)
      VALUES (?, 'active', ?, 'manual')
    `).run(taskName, totalQty);
    
    const taskId = taskResult.lastInsertRowid;
    
    const insertItem = db.prepare(`
      INSERT INTO packing_task_items (task_id, product_id, planned_qty, scanned_qty, requires_marking)
      VALUES (?, ?, ?, 0, ?)
    `);
    
    let itemsCount = 0;
    for (const item of items) {
      const product = db.prepare('SELECT * FROM products WHERE id = ?').get(item.productId);
      if (product) {
        insertItem.run(taskId, product.id, item.quantity || 1, product.requires_marking ? 1 : 0);
        itemsCount++;
      }
    }
    
    await logAction('packing_task_created', 'packing_task', taskId, { source: 'manual', itemsCount, totalQty });
    
    res.json({ 
      success: true, 
      taskId, 
      itemsCount,
      totalQuantity: totalQty 
    });
  } catch (err) {
    console.error('Create task error:', err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
