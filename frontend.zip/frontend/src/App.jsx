import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { useSync } from './hooks/useSync';
import api, { getProducts, uploadLocationsXls } from './api';
import { Package, PackageCheck, Truck, RefreshCw, Search, Upload, Plus, ArrowLeft, CheckCircle, Box, Scan, Minus, AlertTriangle, X, Wifi, Printer } from 'lucide-react';

// Получение локального IP для QR-кода (в одной сети)
const getLocalUrl = (path) => {
  const savedIp = localStorage.getItem('warehouse_local_ip');
  if (savedIp) {
    return `http://${savedIp}:5173${path}`;
  }
  return `${window.location.origin}${path}`;
};

// Стили для печати маршрутного листа
const PrintStyles = () => (
  <style>{`
    @media print {
      /* Базовые настройки */
      html, body {
        margin: 0 !important;
        padding: 0 !important;
        background: white !important;
      }
      
      /* Скрываем всё */
      body > div {
        display: none !important;
      }
      
      /* Показываем только печатный контейнер */
      body > div#print-root {
        display: block !important;
      }
      
      #print-root {
        position: static !important;
        width: 100% !important;
        padding: 0 !important;
        margin: 0 !important;
      }
      
      #print-root * {
        visibility: visible !important;
      }
      
      /* Таблица */
      #print-root table { 
        width: 100% !important;
        border-collapse: collapse !important;
      }
      
      #print-root th, 
      #print-root td { 
        padding: 4px 6px !important;
        font-size: 10pt !important;
        border: 1px solid #333 !important;
      }
      
      /* Заголовки стеллажей */
      #print-root .rack-header td {
        background-color: #dbeafe !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      
      @page { 
        margin: 10mm !important;
        size: A4 portrait !important;
      }
    }
  `}</style>
);

function BarcodeSVG({ value, height = 40 }) {
  if (!value) return null;
  const patterns = {'0':'11011001100','1':'11001101100','2':'11001100110','3':'10010011000','4':'10010001100','5':'10001001100','6':'10011001000','7':'10011000100','8':'10001100100','9':'11001001000','A':'11001000100','B':'11000100100','C':'10110011100','D':'10011011100','E':'10011001110','F':'10111001100','G':'10011101100','H':'10011100110','I':'11001110010','J':'11001011100','K':'11001001110','L':'11011100100','M':'11001110100','N':'11101101110','O':'11101001100','P':'11100101100','Q':'11100100110','R':'11101100100','S':'11100110100','T':'11100110010','U':'11011011000','V':'11011000110','W':'11000110110','X':'10100011000','Y':'10001011000','Z':'10001000110','_':'10110001000',' ':'11011000010','-':'10001101000'};
  let binary = '11010000100';
  for (let c of String(value).toUpperCase()) binary += patterns[c] || patterns['0'];
  binary += '1100011101011';
  const w = 1.5;
  return <svg width={binary.length*w} height={height} viewBox={`0 0 ${binary.length*w} ${height}`}>{binary.split('').map((b,i)=>b==='1'&&<rect key={i} x={i*w} y={0} width={w} height={height} fill="black"/>)}</svg>;
}

// EAN-13 штрих-код генератор
function EAN13SVG({ value, height = 40 }) {
  if (!value || !/^\d{13}$/.test(value)) return null;
  const L = ['0001101','0011001','0010011','0111101','0100011','0110001','0101111','0111011','0110111','0001011'];
  const G = ['0100111','0110011','0011011','0100001','0011101','0111001','0000101','0010001','0001001','0010111'];
  const R = ['1110010','1100110','1101100','1000010','1011100','1001110','1010000','1000100','1001000','1110100'];
  const firstDigitPatterns = ['LLLLLL','LLGLGG','LLGGLG','LLGGGL','LGLLGG','LGGLLG','LGGGLL','LGLGLG','LGLGGL','LGGLGL'];
  
  let binary = '101'; // Start
  const first = parseInt(value[0]);
  const pattern = firstDigitPatterns[first];
  
  for (let i = 1; i <= 6; i++) {
    const digit = parseInt(value[i]);
    binary += pattern[i-1] === 'L' ? L[digit] : G[digit];
  }
  binary += '01010'; // Middle
  for (let i = 7; i <= 12; i++) {
    binary += R[parseInt(value[i])];
  }
  binary += '101'; // End
  
  const w = 1.5;
  return <svg width={binary.length*w} height={height} viewBox={`0 0 ${binary.length*w} ${height}`}>{binary.split('').map((b,i)=>b==='1'&&<rect key={i} x={i*w} y={0} width={w} height={height} fill="black"/>)}</svg>;
}

// Функция выбора правильного штрих-кода в зависимости от контрагента
function getDisplayBarcode(item, counterpartyName) {
  const name = (counterpartyName || '').toLowerCase();
  const barcode = item.barcode || '';
  
  if (name.includes('озон') || name.includes('ozon')) {
    // Для Озона используем OZN штрих-код (уже вычислен на бэкенде)
    const oznBarcode = item.ozn_barcode || '';
    if (oznBarcode) {
      return { barcode: oznBarcode, type: 'code128', isOzon: true };
    }
    // Если нет OZN - пробуем найти в all_barcodes
    const allBarcodes = item.all_barcodes || barcode;
    const barcodes = allBarcodes.split(',').map(b => b.trim());
    const found = barcodes.find(b => b.toUpperCase().startsWith('OZN'));
    return { barcode: found || barcode, type: 'code128', isOzon: true };
  } else if (name.includes('рвб')) {
    // Для РВБ используем EAN-13 штрих-код (уже вычислен на бэкенде)
    const ean13Barcode = item.ean13_barcode || '';
    if (ean13Barcode) {
      return { barcode: ean13Barcode, type: 'ean13', isRVB: true };
    }
    // Если нет EAN-13 - пробуем найти в all_barcodes
    const allBarcodes = item.all_barcodes || barcode;
    const barcodes = allBarcodes.split(',').map(b => b.trim());
    const found = barcodes.find(b => /^\d{13}$/.test(b));
    return { barcode: found || barcode, type: 'ean13', isRVB: true };
  }
  
  // По умолчанию - code128
  return { barcode, type: 'code128', isOzon: false, isRVB: false };
}

// QR Code генератор (простая реализация)
function QRCode({ value, size = 100 }) {
  // Используем внешний API для генерации QR-кода
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(value)}`;
  return <img src={qrUrl} alt="QR Code" width={size} height={size} className="print:w-14 print:h-14" />;
}

function Toast({ message, type, onClose }) {
  useEffect(() => { const t = setTimeout(onClose, 3000); return () => clearTimeout(t); }, [onClose]);
  return <div className={`fixed bottom-4 right-4 ${type==='success'?'bg-emerald-500':type==='error'?'bg-red-500':'bg-blue-500'} text-white px-4 py-3 rounded-xl shadow-lg z-50`}>{message}</div>;
}

function Header({ page, setPage, sync }) {
  const { status, syncing } = sync;
  return (
    <header className="bg-white border-b sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center"><Package className="w-4 h-4 text-white" /></div>
          <nav className="flex gap-1">
            {[['products','Товары',Package],['packing','Упаковка',PackageCheck],['receiving','Приемка',Truck]].map(([id,label,Icon])=>(
              <button key={id} onClick={()=>setPage(id)} className={`flex items-center gap-2 px-3 py-2 rounded-lg ${page===id?'bg-blue-50 text-blue-700':'text-gray-600 hover:bg-gray-50'}`}>
                <Icon className="w-4 h-4"/><span>{label}</span>
              </button>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-3">
          <span className={`text-xs px-2 py-1 rounded-full ${status?.connected?'bg-emerald-100 text-emerald-700':'bg-red-100 text-red-700'}`}>{status?.connected?'МойСклад ✓':'Нет связи'}</span>
          <button onClick={sync.sync} disabled={syncing} className="btn-secondary flex items-center gap-2 text-sm py-2">
            <RefreshCw className={`w-4 h-4 ${syncing?'animate-spin':''}`}/><span>{syncing?'Синхр...':'Синхронизировать'}</span>
          </button>
        </div>
      </div>
    </header>
  );
}

function ProductsPage({ showToast }) {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const locFileRef = useRef();
  const [locUploading, setLocUploading] = useState(false);

  const onUploadLocations = async (file) => {
    if (!file) return;
    try {
      setLocUploading(true);
      const { data } = await uploadLocationsXls(file);
      showToast(`Ячейки обновлены: ${data?.updated ?? 0}`, 'success');
      // Перезагружаем список, чтобы сразу увидеть cell_address в выдаче (если включите в карточке)
      const r = await getProducts({ search, limit: 50 });
      setProducts(r.data.products);
    } catch (e) {
      const msg = e?.response?.data?.error || e?.message || 'Ошибка загрузки отчёта';
      showToast(msg, 'error');
    } finally {
      setLocUploading(false);
      if (locFileRef.current) locFileRef.current.value = '';
    }
  };
  useEffect(() => { setLoading(true); getProducts({ search, limit: 50 }).then(({data})=>setProducts(data.products)).finally(()=>setLoading(false)); }, [search]);
  return (
    <div className="max-w-6xl mx-auto px-4 py-4">
      <div className="card mb-4 flex flex-col sm:flex-row sm:items-center gap-3">
        <div className="flex-1">
          <div className="font-medium">Адреса ячеек (для маршрутного листа)</div>
          <div className="text-sm text-gray-600">Экспортируйте в МойСклад: Склад → Остатки → Остатки по ячейкам → XLS. Затем загрузите сюда.</div>
        </div>
        <input ref={locFileRef} type="file" accept=".xls,.xlsx" className="hidden" onChange={(e)=>onUploadLocations(e.target.files?.[0])} />
        <button className="btn-secondary flex items-center gap-2" onClick={()=>locFileRef.current?.click()} disabled={locUploading}>
          <Upload className="w-4 h-4" /> {locUploading?'Загрузка...':'Загрузить XLS'}
        </button>
      </div>
      <div className="relative mb-4"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"/><input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Поиск товаров..." className="input pl-10"/></div>
      <div className="grid gap-3">
        {loading?<div className="text-center py-8 text-gray-500">Загрузка...</div>:products.length===0?<div className="text-center py-8 text-gray-500">Товары не найдены</div>:products.map(p=>(
          <div key={p.id} className="card flex items-center gap-4">
            <div className="w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center"><Package className="w-6 h-6 text-gray-400"/></div>
            <div className="flex-1"><h3 className="font-medium">{p.name}</h3><p className="text-sm text-gray-500">{p.barcode||'Нет штрихкода'} • {p.article||'—'}</p></div>
            <div className="text-right"><p className="font-bold">{p.stock||0} шт</p><p className="text-sm text-gray-500">{p.price?`${p.price} ₽`:'—'}</p></div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Sound effects helper
const playSound=(type)=>{try{const ctx=new(window.AudioContext||window.webkitAudioContext)();const osc=ctx.createOscillator();const gain=ctx.createGain();osc.connect(gain);gain.connect(ctx.destination);if(type==='success'){osc.frequency.setValueAtTime(880,ctx.currentTime);osc.frequency.setValueAtTime(1100,ctx.currentTime+0.1);gain.gain.setValueAtTime(0.3,ctx.currentTime);osc.start(ctx.currentTime);osc.stop(ctx.currentTime+0.2);}else if(type==='warning'){osc.frequency.setValueAtTime(440,ctx.currentTime);osc.frequency.setValueAtTime(330,ctx.currentTime+0.15);gain.gain.setValueAtTime(0.4,ctx.currentTime);osc.start(ctx.currentTime);osc.stop(ctx.currentTime+0.3);}else if(type==='error'){osc.frequency.setValueAtTime(200,ctx.currentTime);osc.type='square';gain.gain.setValueAtTime(0.3,ctx.currentTime);osc.start(ctx.currentTime);osc.stop(ctx.currentTime+0.4);}else if(type==='complete'){osc.frequency.setValueAtTime(523,ctx.currentTime);osc.frequency.setValueAtTime(659,ctx.currentTime+0.1);osc.frequency.setValueAtTime(784,ctx.currentTime+0.2);gain.gain.setValueAtTime(0.3,ctx.currentTime);osc.start(ctx.currentTime);osc.stop(ctx.currentTime+0.35);}}catch(e){}};

// URL для изображения товара (через наш бэкенд с авторизацией МойСклад)
// Используем product_id для получения изображения напрямую
const getProductImageUrl = (productId) => {
  if (!productId) return null;
  return `/api/products/${productId}/image`;
};

// Компонент изображения товара с fallback на иконку
function ProductImage({ productId, src, alt, className, onClick, clickable = false }) {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  
  // Приоритет: productId (новый способ) > src (старый способ через image_url)
  const imageSrc = productId ? getProductImageUrl(productId) : null;
  
  if (!productId || error) {
    return (
      <div className={`${className} bg-gray-100 flex items-center justify-center`}>
        <Package className="w-6 h-6 text-gray-400" />
      </div>
    );
  }
  
  return (
    <div className={`${className} bg-gray-100 flex items-center justify-center overflow-hidden relative ${clickable ? 'cursor-pointer hover:opacity-80 transition-opacity' : ''}`} onClick={clickable ? onClick : undefined}>
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
          <div className="w-5 h-5 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
        </div>
      )}
      <img 
        src={imageSrc} 
        alt={alt || ''} 
        className={`w-full h-full object-cover transition-opacity ${loading ? 'opacity-0' : 'opacity-100'}`}
        onError={() => { setError(true); setLoading(false); }}
        onLoad={() => setLoading(false)}
      />
    </div>
  );
}

// Модальное окно для увеличенного изображения
function ImageModal({ productId, alt, onClose }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  // Для увеличенного просмотра используем полноразмерное изображение
  const imageSrc = productId ? `/api/products/${productId}/image?full=true` : null;
  
  useEffect(() => {
    const handleEsc = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handleEsc);
    return () => document.removeEventListener('keydown', handleEsc);
  }, [onClose]);
  
  if (!productId) return null;
  
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <button onClick={onClose} className="absolute top-4 right-4 text-white hover:text-gray-300 z-10">
        <X className="w-8 h-8" />
      </button>
      <div className="relative max-w-4xl max-h-[90vh] flex items-center justify-center" onClick={e => e.stopPropagation()}>
        {loading && !error && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-10 h-10 border-4 border-gray-600 border-t-white rounded-full animate-spin"></div>
          </div>
        )}
        {error ? (
          <div className="bg-gray-800 rounded-lg p-8 text-center">
            <Package className="w-16 h-16 text-gray-500 mx-auto mb-4" />
            <p className="text-gray-400">Изображение недоступно</p>
          </div>
        ) : (
          <img 
            src={imageSrc} 
            alt={alt || ''} 
            className={`max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl transition-opacity ${loading ? 'opacity-0' : 'opacity-100'}`}
            onLoad={() => setLoading(false)}
            onError={() => { setError(true); setLoading(false); }}
          />
        )}
      </div>
    </div>
  );
}

function PackingPage({ showToast }) {
  const [tasks, setTasks] = useState([]);
  const [activeTask, setActiveTask] = useState(null);
  const [taskItems, setTaskItems] = useState([]);
  const [showUpload, setShowUpload] = useState(false);
  const [showManual, setShowManual] = useState(false);
  const [showRouteSheet, setShowRouteSheet] = useState(false);
  const [routeSheet, setRouteSheet] = useState(null);
  const [boxes, setBoxes] = useState([]);
  const [activeBoxId, setActiveBoxId] = useState(null);
  const [markingModal, setMarkingModal] = useState(null);
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [qty, setQty] = useState(1);
  const [manualItems, setManualItems] = useState([]);
  // Состояния для просмотра/редактирования короба
  const [showBoxContents, setShowBoxContents] = useState(null); // {box, items, details}
  const [editingBox, setEditingBox] = useState(false);
  const [addProductToBox, setAddProductToBox] = useState(false);
  const [editedQuantities, setEditedQuantities] = useState({}); // {productId: newQty}
  // Состояния для редактирования названия задачи
  const [editingTaskName, setEditingTaskName] = useState(false);
  const [taskNameInput, setTaskNameInput] = useState('');
  // Состояние для модального окна завершения
  const [completedTask, setCompletedTask] = useState(null); // {id, name, demandId, demandError}
  // Состояния для МойСклад
  const [counterparties, setCounterparties] = useState([]);
  const [counterpartySearch, setCounterpartySearch] = useState('');
  const [selectedCounterparty, setSelectedCounterparty] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [organizations, setOrganizations] = useState([]);
  const [stores, setStores] = useState([]);
  const [msSettings, setMsSettings] = useState({ organizationId: null, storeId: null });
  // Таймаут сканирования (защита от двойного пика)
  const [lastScanTime, setLastScanTime] = useState(0);
  const SCAN_TIMEOUT = 500; // 0.5 секунды
  // Штрих-код короба от маркетплейса
  const [showBoxBarcodeModal, setShowBoxBarcodeModal] = useState(null); // {boxId, boxNumber}
  const [boxBarcodeInput, setBoxBarcodeInput] = useState('');
  const boxBarcodeRef = useRef();
  const scanRef = useRef();
  const markingRef = useRef();
  const fileRef = useRef();

  // Загрузка справочников МойСклад
  const loadMoySkladData = async () => {
    try {
      const [orgsRes, storesRes, settingsRes] = await Promise.all([
        api.get('/packing/moysklad/organizations'),
        api.get('/packing/moysklad/stores'),
        api.get('/packing/moysklad/settings')
      ]);
      setOrganizations(orgsRes.data || []);
      setStores(storesRes.data || []);
      setMsSettings(settingsRes.data || {});
    } catch (err) {
      console.error('Failed to load MoySklad data:', err);
    }
  };

  const loadCounterparties = async (searchTerm = '') => {
    try {
      const { data } = await api.get('/packing/moysklad/counterparties', { params: { search: searchTerm } });
      setCounterparties(data || []);
    } catch (err) {
      console.error('Failed to load counterparties:', err);
    }
  };

  const saveMsSettings = async (settings) => {
    try {
      await api.post('/packing/moysklad/settings', settings);
      setMsSettings(prev => ({ ...prev, ...settings }));
      showToast('Настройки сохранены', 'success');
    } catch (err) {
      showToast('Ошибка сохранения', 'error');
    }
  };

  const loadTasks = async () => { try { const {data} = await api.get('/packing/tasks'); setTasks(data); } catch(err) { showToast('Ошибка','error'); }};

  const loadBoxes = async (taskId) => {
    try {
      const { data } = await api.get(`/packing/tasks/${taskId}/boxes`);
      const b = data.boxes || [];
      setBoxes(b);
      // Выбор активного короба: открытый последний, иначе первый
      if (!activeBoxId) {
        const open = b.filter(x => x.status === 'open');
        const pick = (open.length ? open[open.length-1] : b[b.length-1]);
        setActiveBoxId(pick ? pick.id : null);
      } else {
        // если активный короб удален/пропал — выбрать другой
        if (!b.some(x => String(x.id) === String(activeBoxId))) {
          const open = b.filter(x => x.status === 'open');
          const pick = (open.length ? open[open.length-1] : b[b.length-1]);
          setActiveBoxId(pick ? pick.id : null);
        }
      }
    } catch (err) {
      // ignore
    }
  };

  const ensureBox = async (taskId) => {
    try {
      const { data } = await api.post(`/packing/tasks/${taskId}/boxes`);
      const newBox = data?.box;
      await loadBoxes(taskId);
      if (newBox?.id) {
        setActiveBoxId(newBox.id);
        // Показываем модальное окно для ввода штрих-кода короба
        setShowBoxBarcodeModal({ boxId: newBox.id, boxNumber: newBox.number });
        setBoxBarcodeInput('');
      }
      return newBox?.id;
    } catch (e) {
      return null;
    }
  };
  
  // Сохранение штрих-кода короба от маркетплейса
  const handleSaveBoxBarcode = async () => {
    if (!showBoxBarcodeModal) return;
    const barcode = boxBarcodeInput.trim();
    try {
      await api.put(`/packing/tasks/${activeTask.id}/boxes/${showBoxBarcodeModal.boxId}`, { 
        marketplace_barcode: barcode || null 
      });
      await loadBoxes(activeTask.id);
      setShowBoxBarcodeModal(null);
      setBoxBarcodeInput('');
      showToast(barcode ? 'Штрих-код короба сохранён' : 'Короб создан без штрих-кода', 'success');
      setTimeout(() => scanRef.current?.focus(), 100);
    } catch (err) {
      showToast(err.response?.data?.error || 'Ошибка', 'error');
    }
  };
  
  // Пропустить ввод штрих-кода короба
  const handleSkipBoxBarcode = () => {
    setShowBoxBarcodeModal(null);
    setBoxBarcodeInput('');
    setTimeout(() => scanRef.current?.focus(), 100);
  };

  // Фокус на поле ввода штрих-кода короба
  useEffect(() => {
    if (showBoxBarcodeModal) {
      setTimeout(() => boxBarcodeRef.current?.focus(), 100);
    }
  }, [showBoxBarcodeModal]);

  const loadTask = async (id) => {
    try {
      const {data} = await api.get(`/packing/tasks/${id}`);
      setActiveTask(data.task);
      setTaskItems(data.items);
      await loadBoxes(id);
      // Если коробов нет — создаем первый автоматически
      const hasBoxes = (data && boxes && boxes.length > 0);
      // can't rely on state immediately; check on server
      const bx = await api.get(`/packing/tasks/${id}/boxes`).then(r=>r.data.boxes||[]).catch(()=>[]);
      setBoxes(bx);
      if (bx.length === 0) {
        const nid = await ensureBox(id);
        if (nid) setActiveBoxId(nid);
      } else {
        const open = bx.filter(x=>x.status==='open');
        const pick = (open.length ? open[open.length-1] : bx[bx.length-1]);
        setActiveBoxId(pick ? pick.id : null);
      }
    } catch(err) {
      showToast('Ошибка','error');
    }
  };
  
  useEffect(() => { loadTasks(); loadMoySkladData(); }, []);
  useEffect(() => { if (showUpload) loadCounterparties(); }, [showUpload]);
  useEffect(() => { if (showManual) getProducts({search,limit:50}).then(({data})=>setProducts(data.products)); }, [showManual, search]);

  useEffect(() => {
    if (markingModal) {
      setTimeout(() => markingRef.current?.focus(), 50);
    }
  }, [markingModal]);

  // Автофокус на поле сканирования (как в Приёмке)
  useEffect(() => {
    if (!activeTask || activeTask.status !== 'active') return;
    
    const focus = () => { 
      // Не фокусируемся если открыты модальные окна или редактируется название
      if (!showRouteSheet && !markingModal && !showBoxContents && !showUpload && !showManual && !addProductToBox && !editingTaskName && !showBoxBarcodeModal) {
        scanRef.current?.focus(); 
      }
    };
    
    focus();
    
    // При клике вне input/button — возвращаем фокус
    const onClick = (e) => { 
      if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'BUTTON' && !e.target.closest('button')) {
        setTimeout(focus, 50); 
      }
    };
    
    // При нажатии любой клавиши — возвращаем фокус (для сканера)
    const onKey = () => { 
      if (!showRouteSheet && !markingModal && !showBoxContents && !showUpload && !showManual && !addProductToBox && !editingTaskName && !showBoxBarcodeModal) {
        if (document.activeElement !== scanRef.current) {
          scanRef.current?.focus(); 
        }
      }
    };
    
    document.addEventListener('click', onClick);
    document.addEventListener('keydown', onKey);
    
    return () => { 
      document.removeEventListener('click', onClick); 
      document.removeEventListener('keydown', onKey); 
    };
  }, [activeTask, showRouteSheet, markingModal, showBoxContents, showUpload, showManual, addProductToBox, editingTaskName, showBoxBarcodeModal]);

  

  const handleScan = async (barcode) => {
    if (!barcode.trim() || !activeTask) return;
    
    // Защита от двойного сканирования (0.5 сек)
    const now = Date.now();
    if (now - lastScanTime < SCAN_TIMEOUT) {
      console.log('Scan ignored (timeout)');
      return;
    }
    setLastScanTime(now);
    
    const cleaned = barcode.trim();
    
    // Проверка формата штрих-кода в зависимости от контрагента
    const counterpartyName = activeTask.counterparty_name?.toLowerCase() || '';
    if (counterpartyName.includes('озон') || counterpartyName.includes('ozon')) {
      // Для Озона ожидаем штрих-коды OZN + цифры
      if (!cleaned.toUpperCase().startsWith('OZN')) {
        playSound('error');
        showToast('Для Озон нужен штрих-код формата OZN...', 'error');
        return;
      }
    } else if (counterpartyName.includes('рвб')) {
      // Для РВБ ожидаем EAN-13 (13 цифр)
      if (!/^\d{13}$/.test(cleaned)) {
        playSound('error');
        showToast('Для РВБ нужен штрих-код EAN-13 (13 цифр)', 'error');
        return;
      }
    }

    // Ensure we have an active box
    let boxId = activeBoxId;
    if (!boxId) {
      boxId = await ensureBox(activeTask.id);
      if (!boxId) {
        playSound('error');
        showToast('Не удалось создать короб','error');
        return;
      }
    }

    // Если товар маркируемый — сначала попросим код маркировки
    const item = taskItems.find(i => String(i.barcode || '').trim() === cleaned);
    if (item && Number(item.requires_marking) === 1) {
      setMarkingModal({ barcode: cleaned, product: item.name, boxId });
      // фокус на поле маркировки появится в useEffect ниже
      return;
    }

    try {
      const { data } = await api.post(`/packing/tasks/${activeTask.id}/scan`, { barcode: cleaned, boxId });
      playSound(data.complete ? 'success' : 'warning');
      showToast(`${data.product}: ${data.scanned}/${data.quantity}`, data.complete ? 'success' : 'info');
      await loadTask(activeTask.id);
      await loadBoxes(activeTask.id);
    } catch (err) {
      playSound('error');
      showToast(err.response?.data?.error || 'Ошибка','error');
    }
  };

  const submitMarking = async (markingCode) => {
    if (!markingModal || !activeTask) return;
    const code = String(markingCode || '').trim();
    if (!code) {
      playSound('error');
      showToast('Сканируйте/введите код маркировки','error');
      return;
    }
    try {
      const { data } = await api.post(`/packing/tasks/${activeTask.id}/scan`, {
        barcode: markingModal.barcode,
        boxId: markingModal.boxId,
        chestnyZnak: code,
      });
      playSound(data.complete ? 'success' : 'warning');
      showToast(`${data.product}: ${data.scanned}/${data.quantity}`, data.complete ? 'success' : 'info');
      setMarkingModal(null);
      await loadTask(activeTask.id);
      await loadBoxes(activeTask.id);
      setTimeout(() => scanRef.current?.focus(), 50);
    } catch (err) {
      playSound('error');
      showToast(err.response?.data?.error || 'Ошибка','error');
    }
  };

  const handleUpload = async (e) => { 
    const file = e.target.files?.[0]; 
    if (!file) return; 
    const fd = new FormData(); 
    fd.append('file',file);
    if (selectedCounterparty) {
      fd.append('counterpartyId', selectedCounterparty.id);
      fd.append('counterpartyName', selectedCounterparty.name);
    }
    try { 
      const {data} = await api.post('/packing/tasks/upload',fd);
      
      // Формируем сообщение с результатами
      let msg = `Создано ${data.created} позиций`;
      if (data.customerOrderId) msg += '. Заказ и отгрузка созданы в МойСклад';
      else if (data.moySkladError) msg += `. МойСклад: ${data.moySkladError}`;
      
      showToast(msg, data.customerOrderId ? 'success' : 'info'); 
      setShowUpload(false);
      setSelectedCounterparty(null);
      setCounterpartySearch('');
      loadTasks();
      if (data.taskId) loadTask(data.taskId);
    } catch(err) { 
      showToast(err.response?.data?.error||'Ошибка загрузки','error'); 
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleAddManualItem = () => {
    if (!selected) return;
    const existing = manualItems.find(i => i.product.id === selected.id);
    if (existing) {
      setManualItems(manualItems.map(i => i.product.id === selected.id ? {...i, quantity: i.quantity + qty} : i));
    } else {
      setManualItems([...manualItems, { product: selected, quantity: qty }]);
    }
    setSelected(null);
    setQty(1);
  };

  const handleCreateManualTask = async () => {
    if (manualItems.length === 0) return;
    try {
      const {data} = await api.post('/packing/tasks', { 
        items: manualItems.map(i => ({ productId: i.product.id, quantity: i.quantity }))
      });
      showToast(`Создана задача: ${data.itemsCount} позиций`,'success');
      setShowManual(false);
      setManualItems([]);
      loadTasks();
      if (data.taskId) loadTask(data.taskId);
    } catch(err) {
      showToast('Ошибка создания','error');
    }
  };

  const handleComplete = async () => {
    if (!activeTask) return;
    try {
      const taskId = activeTask.id;
      const taskName = activeTask.name;
      const {data} = await api.post(`/packing/tasks/${taskId}/complete`);
      playSound('complete');
      
      // Показываем модальное окно с результатами и кнопками Excel
      setCompletedTask({
        id: taskId,
        name: taskName,
        message: data.message,
        demandId: data.demandId,
        demandError: data.demandError
      });
      
      setActiveTask(null);
      loadTasks();
    } catch(err) {
      showToast(err.response?.data?.error||'Ошибка','error');
    }
  };

  // Скачивание Excel файлов
  const downloadExcel = async (taskId, type) => {
    try {
      const response = await api.get(`/packing/tasks/${taskId}/export/${type}`, {
        responseType: 'blob'
      });
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', type === 'products' ? 'products.xlsx' : 'boxes.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      showToast('Ошибка скачивания', 'error');
    }
  };

  const handleNewBox = async () => {
    if (!activeTask) return;
    try {
      const { data } = await api.post(`/packing/tasks/${activeTask.id}/boxes`);
      const newBox = data?.box;
      await loadBoxes(activeTask.id);
      if (newBox?.id) {
        setActiveBoxId(newBox.id);
        // Показываем модальное окно для ввода штрих-кода короба
        setShowBoxBarcodeModal({ boxId: newBox.id, boxNumber: newBox.number });
        setBoxBarcodeInput('');
      }
      playSound('warning');
    } catch (err) {
      playSound('error');
      showToast(err.response?.data?.error || 'Ошибка создания короба','error');
    }
  };

  const handleCloseBox = async () => {
    if (!activeTask || !activeBoxId) return;
    try {
      await api.post(`/packing/tasks/${activeTask.id}/boxes/${activeBoxId}/close`);
      playSound('success');
      showToast('Короб закрыт','success');
      await loadBoxes(activeTask.id);
      // Автоматически создаём новый короб для продолжения
      const { data } = await api.post(`/packing/tasks/${activeTask.id}/boxes`);
      const newId = data?.box?.id;
      await loadBoxes(activeTask.id);
      if (newId) setActiveBoxId(newId);
      setTimeout(() => scanRef.current?.focus(), 50);
    } catch (err) {
      playSound('error');
      const msg = err.response?.data?.error || 'Ошибка закрытия короба';
      showToast(msg,'error');
    }
  };

  // Функции для просмотра/редактирования содержимого короба
  const loadBoxContents = async (boxId) => {
    try {
      const { data } = await api.get(`/packing/tasks/${activeTask.id}/boxes/${boxId}/items`);
      setShowBoxContents(data);
      setEditingBox(false);
      setAddProductToBox(false);
      setEditedQuantities({}); // Сбрасываем локальные изменения
    } catch (err) {
      showToast('Ошибка загрузки содержимого', 'error');
    }
  };

  // Обновление количества - теперь сохраняем изменения локально, применяем при нажатии на кнопку
  const handleUpdateBoxItem = async (productId, newQty) => {
    if (!showBoxContents) return;
    try {
      await api.put(`/packing/tasks/${activeTask.id}/boxes/${showBoxContents.box.id}/items/${productId}`, { quantity: newQty });
      // Обновляем локальный state без перезагрузки
      setShowBoxContents(prev => ({
        ...prev,
        items: prev.items.map(item => 
          item.product_id === productId 
            ? { ...item, quantity: newQty }
            : item
        ).filter(item => item.quantity > 0),
        totalItems: prev.items.reduce((sum, item) => 
          sum + (item.product_id === productId ? newQty : item.quantity), 0
        )
      }));
      // Тихо обновляем данные задачи в фоне
      loadTask(activeTask.id);
      loadBoxes(activeTask.id);
    } catch (err) {
      showToast(err.response?.data?.error || 'Ошибка', 'error');
    }
  };

  const handleDeleteBoxItem = async (productId) => {
    if (!showBoxContents) return;
    try {
      await api.delete(`/packing/tasks/${activeTask.id}/boxes/${showBoxContents.box.id}/items/${productId}`);
      showToast('Товар удалён из короба', 'success');
      // Обновляем локальный state
      setShowBoxContents(prev => ({
        ...prev,
        items: prev.items.filter(item => item.product_id !== productId),
        totalItems: prev.items.filter(item => item.product_id !== productId)
          .reduce((sum, item) => sum + item.quantity, 0)
      }));
      loadTask(activeTask.id);
      loadBoxes(activeTask.id);
    } catch (err) {
      showToast(err.response?.data?.error || 'Ошибка', 'error');
    }
  };

  const handleAddProductToBox = async (productId, quantity) => {
    if (!showBoxContents) return;
    try {
      const { data } = await api.post(`/packing/tasks/${activeTask.id}/boxes/${showBoxContents.box.id}/items`, { productId, quantity });
      showToast(data.message, 'success');
      setAddProductToBox(false);
      setSelected(null);
      setQty(1);
      setSearch('');
      await loadBoxContents(showBoxContents.box.id);
      await loadTask(activeTask.id);
    } catch (err) {
      showToast(err.response?.data?.error || 'Ошибка', 'error');
    }
  };

  const handleReopenBox = async (boxId) => {
    try {
      await api.post(`/packing/tasks/${activeTask.id}/boxes/${boxId}/reopen`);
      showToast('Короб открыт для редактирования', 'success');
      await loadBoxes(activeTask.id);
      if (showBoxContents && showBoxContents.box.id === boxId) {
        await loadBoxContents(boxId);
      }
    } catch (err) {
      showToast(err.response?.data?.error || 'Ошибка', 'error');
    }
  };

  // Обновление названия задачи
  const handleUpdateTaskName = async () => {
    if (!taskNameInput.trim() || !activeTask) return;
    try {
      await api.put(`/packing/tasks/${activeTask.id}`, { name: taskNameInput.trim() });
      setActiveTask(prev => ({ ...prev, name: taskNameInput.trim() }));
      setEditingTaskName(false);
      showToast('Название обновлено', 'success');
      loadTasks();
    } catch (err) {
      showToast(err.response?.data?.error || 'Ошибка', 'error');
    }
  };

  // Печать этикетки короба (58x60 мм)
  const printBoxLabel = (box) => {
    const taskName = activeTask?.name || 'Сборка';
    // Извлекаем "город" из названия (убираем стандартный префикс)
    let city = taskName.replace(/^Сборка\s*\d{2}\.\d{2}\.\d{4}\s*\d{2}:\d{2}\s*/i, '').trim();
    if (!city) city = taskName;
    
    // Извлекаем время
    const timeMatch = taskName.match(/(\d{2}:\d{2})/);
    const time = timeMatch ? timeMatch[1] : new Date().toLocaleTimeString('ru', {hour:'2-digit', minute:'2-digit'});
    
    // Создаём новое окно для печати с минимальным размером
    const printWin = window.open('', 'printLabel', 'width=220,height=230,menubar=no,toolbar=no,location=no,status=no');
    
    printWin.document.write(`<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Этикетка</title>
<style>
@media print {
  @page { size: 58mm 60mm; margin: 0; }
  html, body { width: 58mm; height: 60mm; }
}
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body {
  width: 58mm;
  height: 60mm;
  font-family: Arial, sans-serif;
}
body {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 2mm;
}
.city { font-size: 5mm; font-weight: bold; margin-bottom: 1mm; }
.num { font-size: 18mm; font-weight: bold; line-height: 1; }
.time { font-size: 4mm; color: #333; margin-top: 1mm; }
</style>
</head>
<body>
<div class="city">${city}</div>
<div class="num">#${box.number}</div>
<div class="time">${time}</div>
<script>
window.onload = function() {
  window.print();
  window.onafterprint = function() { window.close(); };
  setTimeout(function() { window.close(); }, 3000);
};
</script>
</body>
</html>`);
    printWin.document.close();
  };

  // Печать этикетки товара (58x60 мм)
  const printProductLabel = async (item) => {
    try {
      // Загружаем полную информацию о товаре с доп. полями из МойСклад
      const { data } = await api.get(`/products/${item.product_id}/label-info`);
      const product = data.product || item;
      const attrs = data.attributes || {};
      
      const name = product.name || item.name || 'Товар';
      const article = product.article || item.article || '';
      
      // Получаем правильный штрих-код в зависимости от контрагента
      const barcodeInfo = getDisplayBarcode(item, activeTask?.counterparty_name);
      const barcode = barcodeInfo.barcode || product.barcode || item.barcode || '';
      const barcodeFormat = barcodeInfo.type === 'ean13' ? 'EAN13' : 'CODE128';
      
      // Извлекаем только даты (цифры и разделители)
      const extractDate = (str) => {
        if (!str) return '';
        const match = String(str).match(/(\d{1,2}[\.\/\-]\d{1,2}[\.\/\-]\d{2,4})/);
        return match ? match[1] : '';
      };
      
      const manufactureDate = extractDate(attrs.manufactureDate);
      const expiryDate = extractDate(attrs.expiryDate);
      const country = attrs.country || '';
      const size = attrs.size || '';
      const color = attrs.color || '';
      
      // Создаём окно печати
      const printWin = window.open('', 'printProductLabel', 'width=250,height=270,menubar=no,toolbar=no,location=no,status=no');
      
      printWin.document.write(`<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Этикетка</title>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"><\/script>
<style>
@media print { @page { size: 58mm 60mm; margin: 0; } }
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 58mm; height: 60mm; overflow: hidden; }
body { font-family: Arial, sans-serif; padding: 1.5mm; }
.name { font-size: 2.8mm; font-weight: bold; text-align: center; line-height: 1.15; margin-bottom: 1mm; }
.row { font-size: 2.2mm; text-align: center; line-height: 1.25; }
.barcode-area { text-align: center; margin-top: 1.5mm; }
.barcode-area svg { width: 52mm; height: 18mm; }
.bc-num { font-size: 3.2mm; font-family: monospace; font-weight: bold; margin-top: 0.5mm; }
</style>
</head>
<body>
<div class="name">${name.length > 45 ? name.substring(0, 45) + '...' : name}</div>
${article ? `<div class="row">${article}</div>` : ''}
${manufactureDate ? `<div class="row"><b>Дата изготовления:</b> ${manufactureDate}</div>` : ''}
${expiryDate ? `<div class="row"><b>Годен до:</b> ${expiryDate}</div>` : ''}
${country ? `<div class="row">${country}</div>` : ''}
${size ? `<div class="row"><b>Размер:</b> ${size}</div>` : ''}
${color ? `<div class="row"><b>Цвет:</b> ${color}</div>` : ''}
<div class="barcode-area">
<svg id="barcode"></svg>
<div class="bc-num">${barcode}</div>
</div>
<script>
try { JsBarcode("#barcode", "${barcode}", { format: "${barcodeFormat}", width: 2, height: 50, displayValue: false, margin: 0 }); } catch(e) {}
setTimeout(function() { window.print(); window.onafterprint = function() { window.close(); }; setTimeout(function() { window.close(); }, 3000); }, 300);
<\/script>
</body>
</html>`);
      printWin.document.close();
      
    } catch (err) {
      console.error('Print product label error:', err);
      showToast('Ошибка загрузки данных товара', 'error');
    }
  };

  const loadRouteSheet = async () => {
    try {
      const {data} = await api.get(`/packing/tasks/${activeTask.id}/route-sheet`);
      setRouteSheet(data);
      setShowRouteSheet(true);
    } catch(err) {
      showToast('Ошибка загрузки','error');
    }
  };

  if (activeTask) {
    const total = taskItems.reduce((s,i)=>s+(i.planned_qty||0),0);
    const scanned = taskItems.reduce((s,i)=>s+(i.scanned_qty||0),0);
    const progress = total>0?(scanned/total)*100:0;
    const openBoxes = boxes.filter(b => b.status === 'open').length;
    const closedBoxes = boxes.filter(b => b.status === 'closed').length;
    const currentBox = boxes.find(b => String(b.id) === String(activeBoxId));
    
    return (
      <div className="max-w-5xl mx-auto px-4 py-4">
        {/* Заголовок с навигацией */}
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <button onClick={()=>{setActiveTask(null);setTaskItems([]);setBoxes([]);setActiveBoxId(null);}} className="btn-secondary p-2"><ArrowLeft className="w-5 h-5"/></button>
          <div className="flex-1 min-w-[200px]">
            {editingTaskName ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={taskNameInput}
                  onChange={(e) => setTaskNameInput(e.target.value)}
                  className="px-3 py-1.5 border-2 rounded-lg text-lg font-bold focus:border-blue-500 focus:ring-0 outline-none"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleUpdateTaskName();
                    if (e.key === 'Escape') setEditingTaskName(false);
                  }}
                  placeholder="Название / Город"
                />
                <button onClick={handleUpdateTaskName} className="p-1.5 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600">
                  <CheckCircle className="w-4 h-4" />
                </button>
                <button onClick={() => setEditingTaskName(false)} className="p-1.5 bg-gray-200 text-gray-600 rounded-lg hover:bg-gray-300">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-lg">{activeTask.name}</h2>
                <button 
                  onClick={() => { setTaskNameInput(activeTask.name); setEditingTaskName(true); }}
                  className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded"
                  title="Редактировать название"
                >
                  ✏️
                </button>
              </div>
            )}
            <p className="text-sm text-gray-500">
              Собрано: {scanned} / {total}
              {activeTask.counterparty_name && <span className="ml-2 text-blue-600">• {activeTask.counterparty_name}</span>}
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button onClick={loadRouteSheet} className="btn-secondary flex items-center gap-2 text-sm">
              <Package className="w-4 h-4"/> Маршрутный лист
            </button>
            {/* Статус документов МойСклад */}
            {activeTask.customer_order_id && (
              <span className="text-xs text-blue-600 flex items-center gap-1 px-2 py-1 bg-blue-50 rounded-lg">
                📋 Заказ создан
              </span>
            )}
            {activeTask.demand_id && (
              <span className="text-xs text-amber-600 flex items-center gap-1 px-2 py-1 bg-amber-50 rounded-lg">
                📦 Отгрузка готова
              </span>
            )}
            {activeTask.status==='active' && scanned > 0 && (
              <button onClick={handleComplete} className="bg-emerald-500 text-white px-4 py-2 rounded-xl font-medium flex items-center gap-2">
                <CheckCircle className="w-4 h-4"/> Завершить
              </button>
            )}
          </div>
        </div>
        
        {/* ===== БЛОК СКАНИРОВАНИЯ И УПРАВЛЕНИЯ КОРОБАМИ ===== */}
        {activeTask.status === 'active' && (
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-5 mb-4 shadow-lg">
            {/* Верхняя часть: текущий короб и кнопки */}
            <div className="flex items-center justify-between gap-4 mb-4 flex-wrap">
              {/* Текущий короб */}
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Box className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-blue-100 text-sm">Текущий короб</p>
                  <p className="text-white font-bold text-xl">
                    {currentBox ? `Короб #${currentBox.number}` : 'Не выбран'}
                  </p>
                  {/* Штрих-код короба маркетплейса */}
                  {currentBox?.marketplace_barcode && (
                    <p className="text-blue-200 text-xs mt-0.5">📦 {currentBox.marketplace_barcode}</p>
                  )}
                </div>
                {/* Кнопки: Состав и Печать этикетки */}
                {currentBox && (
                  <div className="flex gap-1 ml-2">
                    <button
                      onClick={() => loadBoxContents(currentBox.id)}
                      className="px-3 py-1.5 rounded-lg text-sm bg-white/20 text-white hover:bg-white/30 transition-all flex items-center gap-1"
                      title="Посмотреть состав короба"
                    >
                      👁 Состав
                    </button>
                    <button
                      onClick={() => printBoxLabel(currentBox)}
                      className="px-3 py-1.5 rounded-lg text-sm bg-white/20 text-white hover:bg-white/30 transition-all flex items-center gap-1"
                      title="Печать этикетки короба"
                    >
                      🏷️ Этикетка
                    </button>
                  </div>
                )}
              </div>
              
              {/* Счётчик коробов */}
              <div className="flex items-center gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-white">{closedBoxes}</p>
                  <p className="text-blue-200 text-xs">Закрыто</p>
                </div>
                <div className="w-px h-8 bg-white/20"></div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-white">{openBoxes}</p>
                  <p className="text-blue-200 text-xs">Открыто</p>
                </div>
              </div>
              
              {/* Кнопки управления */}
              <div className="flex gap-2">
                <button 
                  onClick={handleCloseBox} 
                  disabled={!activeBoxId || currentBox?.status === 'closed'} 
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium transition-all ${
                    activeBoxId && currentBox?.status !== 'closed'
                      ? 'bg-amber-500 text-white hover:bg-amber-400 shadow-lg' 
                      : 'bg-white/10 text-white/40 cursor-not-allowed'
                  }`}
                >
                  <CheckCircle className="w-4 h-4" /> Закрыть короб
                </button>
                <button 
                  onClick={handleNewBox} 
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium bg-white text-blue-600 hover:bg-blue-50 shadow-lg transition-all"
                >
                  <Plus className="w-4 h-4" /> Новый короб
                </button>
              </div>
            </div>
            
            {/* Список коробов (без глазок) */}
            {boxes.length > 1 && (
              <div className="flex flex-wrap gap-2 mb-4 pb-4 border-b border-white/20">
                {boxes.map(b => (
                  <button 
                    key={b.id}
                    onClick={() => {
                      if (b.status === 'open') setActiveBoxId(b.id);
                      else loadBoxContents(b.id); // Закрытые короба открываем для просмотра
                    }} 
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${
                      String(activeBoxId) === String(b.id)
                        ? 'bg-white text-blue-600 shadow-lg' 
                        : b.status === 'closed'
                          ? 'bg-white/10 text-white/60 hover:bg-white/20 cursor-pointer'
                          : 'bg-white/20 text-white hover:bg-white/30 cursor-pointer'
                    }`}
                    title={b.status === 'closed' ? 'Нажмите для просмотра содержимого' : ''}
                  >
                    <span>#{b.number}</span>
                    {b.status === 'closed' && <CheckCircle className="w-3 h-3" />}
                    {b.total_qty > 0 && <span className="text-xs opacity-70">({b.total_qty})</span>}
                  </button>
                ))}
              </div>
            )}
            
            {/* Поле сканирования */}
            <div>
              <div className="flex items-center gap-2 mb-2 text-white/80">
                <Scan className="w-4 h-4" />
                <span className="text-sm font-medium">Сканирование штрихкода</span>
              </div>
              <input 
                ref={scanRef} 
                type="text" 
                placeholder="Отсканируйте или введите штрихкод..." 
                className="w-full px-5 py-4 rounded-xl text-xl font-mono text-gray-900 bg-white shadow-inner focus:ring-4 focus:ring-white/30 outline-none" 
                autoFocus 
                onKeyDown={e => {
                  if (e.key === 'Enter' && e.target.value) {
                    handleScan(e.target.value);
                    e.target.value = '';
                  }
                }}
              />
            </div>
          </div>
        )}
        
        {/* ===== ОБЩИЙ ПРОГРЕСС ===== */}
        <div className="card mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-600">Общий прогресс</span>
            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-500">{scanned} из {total} шт</span>
              <span className={`font-bold text-lg ${progress >= 100 ? 'text-emerald-600' : 'text-blue-600'}`}>{Math.round(progress)}%</span>
            </div>
          </div>
          <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-500 ${progress >= 100 ? 'bg-emerald-500' : 'bg-blue-500'}`} 
              style={{width: `${Math.min(progress, 100)}%`}}
            />
          </div>
        </div>

        {/* ===== СПИСОК ТОВАРОВ ===== */}
        <div className="mb-2 flex items-center justify-between">
          <h3 className="font-semibold text-gray-700">Товары к упаковке</h3>
          <span className="text-sm text-gray-500">{taskItems.length} позиций</span>
        </div>
        
        <div className="space-y-2">
          {taskItems.map(item => {
            const itemScanned = item.scanned_qty || 0;
            const itemPlanned = item.planned_qty || 0;
            const itemProgress = itemPlanned > 0 ? (itemScanned / itemPlanned) * 100 : 0;
            const complete = itemScanned >= itemPlanned;
            const hasStock = (item.stock || 0) > 0;
            const partial = itemScanned > 0 && itemScanned < itemPlanned;
            
            return (
              <div 
                key={item.id} 
                className={`card flex items-center gap-4 transition-all ${
                  complete 
                    ? 'bg-emerald-50 border-emerald-200' 
                    : !hasStock 
                      ? 'bg-red-50 border-red-200' 
                      : partial 
                        ? 'bg-amber-50 border-amber-200' 
                        : ''
                }`}
              >
                {/* Фото товара */}
                <ProductImage 
                  productId={item.product_id}
                  alt={item.name}
                  className="w-16 h-16 rounded-xl flex-shrink-0 border"
                />
                
                {/* Информация о товаре */}
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm mb-1 line-clamp-2">{item.name}</p>
                  
                  {/* Штрихкод и ячейка */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {(() => {
                      const barcodeInfo = getDisplayBarcode(item, activeTask?.counterparty_name);
                      return barcodeInfo.barcode ? (
                        <span className={`text-xs px-2 py-0.5 rounded font-mono ${
                          barcodeInfo.isOzon ? 'bg-blue-100 text-blue-700' : 
                          barcodeInfo.isRVB ? 'bg-purple-100 text-purple-700' : 
                          'bg-gray-100 text-gray-600'
                        }`}>
                          {barcodeInfo.barcode}
                        </span>
                      ) : null;
                    })()}
                    {item.cell_address && (
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded flex items-center gap-1">
                        📍 {item.cell_address}
                      </span>
                    )}
                  </div>
                  
                  {/* Мини прогресс-бар для позиции */}
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden max-w-[120px]">
                      <div 
                        className={`h-full transition-all ${
                          complete ? 'bg-emerald-500' : partial ? 'bg-amber-500' : 'bg-gray-300'
                        }`}
                        style={{width: `${Math.min(itemProgress, 100)}%`}}
                      />
                    </div>
                    <span className={`text-xs ${!hasStock ? 'text-red-600' : 'text-gray-500'}`}>
                      {hasStock ? `Остаток: ${item.stock}` : 'Нет на складе'}
                    </span>
                  </div>
                </div>
                
                {/* Счётчик и статус */}
                <div className="text-right flex flex-col items-end gap-1">
                  <div className={`font-bold text-2xl ${
                    complete ? 'text-emerald-600' : partial ? 'text-amber-600' : 'text-gray-800'
                  }`}>
                    {itemScanned}<span className="text-gray-400 font-normal text-lg">/{itemPlanned}</span>
                  </div>
                  
                  {/* Кнопка печати этикетки товара */}
                  <button
                    onClick={(e) => { e.stopPropagation(); printProductLabel(item); }}
                    className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                    title="Печать этикетки товара"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                  
                  {/* Статус иконка */}
                  {complete ? (
                    <div className="flex items-center gap-1 text-emerald-600">
                      <CheckCircle className="w-5 h-5" />
                      <span className="text-xs font-medium">Готово</span>
                    </div>
                  ) : partial ? (
                    <div className="flex items-center gap-1 text-amber-600">
                      <Box className="w-4 h-4" />
                      <span className="text-xs font-medium">Частично</span>
                    </div>
                  ) : !hasStock ? (
                    <div className="flex items-center gap-1 text-red-600">
                      <AlertTriangle className="w-4 h-4" />
                      <span className="text-xs font-medium">Нет</span>
                    </div>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>

        {/* Route Sheet Modal */}
        {showRouteSheet && routeSheet && (
          <>
            {/* Модальное окно для просмотра на экране */}
            <div className="fixed inset-0 bg-black/50 z-50" onClick={()=>setShowRouteSheet(false)}></div>
            <div className="fixed inset-4 z-50 flex items-start justify-center overflow-auto">
              <div className="bg-white rounded-2xl max-w-4xl w-full my-4" onClick={e=>e.stopPropagation()}>
                <div className="flex justify-between items-center p-4 border-b">
                  <div>
                    <h2 className="text-xl font-bold">Маршрутный лист</h2>
                    <p className="text-sm text-gray-500">{routeSheet.task.name}</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={()=>setShowRouteSheet(false)} className="btn-secondary text-sm">✕ Закрыть</button>
                    <button onClick={()=>window.print()} className="btn-primary text-sm">🖨️ Печать</button>
                  </div>
                </div>
                
                <div className="px-4 py-2 bg-amber-50 border-b border-amber-200">
                  <div className="flex items-center gap-2 text-sm flex-wrap">
                    <Wifi className="w-4 h-4 text-amber-600" />
                    <span className="text-amber-700">Локальный IP:</span>
                    <input 
                      type="text" 
                      placeholder="192.168.1.100"
                      defaultValue={localStorage.getItem('warehouse_local_ip') || ''}
                      className="px-2 py-1 border rounded text-sm w-36"
                      onChange={(e) => {
                        const ip = e.target.value.trim();
                        if (ip) localStorage.setItem('warehouse_local_ip', ip);
                        else localStorage.removeItem('warehouse_local_ip');
                      }}
                    />
                    <span className="text-amber-600 text-xs">💡 Windows: ipconfig | Mac: Настройки → Сеть</span>
                  </div>
                </div>
                
                <div className="p-4 bg-white max-h-[60vh] overflow-auto">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h1 className="text-lg font-bold">{routeSheet.task.name}</h1>
                      <p className="text-sm text-gray-600">К сбору: <strong>{routeSheet.totalToCollect}</strong> шт • {routeSheet.available} позиций</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <QRCode value={getLocalUrl(`/route/${activeTask.id}`)} size={72} />
                      <span className="text-[10px] text-gray-500">📱 Скан</span>
                    </div>
                  </div>
                  
                  <table className="w-full text-sm border-collapse">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="border border-gray-300 px-2 py-1 text-left w-24">Ячейка</th>
                        <th className="border border-gray-300 px-2 py-1 text-left">Товар</th>
                        <th className="border border-gray-300 px-2 py-1 text-center w-12">Кол</th>
                        <th className="border border-gray-300 px-2 py-1 text-center w-10">✓</th>
                      </tr>
                    </thead>
                    <tbody>
                      {routeSheet.zones.map((zone, zi) => (
                        <React.Fragment key={`z-${zi}`}>
                          <tr><td colSpan={4} className="border border-gray-300 px-2 py-1 font-bold bg-blue-100">📍 Стеллаж {zone.rack}</td></tr>
                          {zone.items.map((item, ii) => (
                            <tr key={`i-${zi}-${ii}`}>
                              <td className="border border-gray-300 px-2 py-1 font-mono text-xs">{item.cell_address ? item.cell_address.replace(/Стеллаж \d+ /i, '').replace(/полка/i, 'п').replace(/ячейка/i, 'яч') : '—'}</td>
                              <td className="border border-gray-300 px-2 py-1"><div className="text-sm">{item.name}</div><div className="text-gray-600 text-xs">{item.barcode}</div></td>
                              <td className="border border-gray-300 px-2 py-1 text-center font-bold">{item.qty_to_collect}</td>
                              <td className="border border-gray-300 px-2 py-1 text-center"><div className="w-4 h-4 border-2 border-gray-400 mx-auto"></div></td>
                            </tr>
                          ))}
                        </React.Fragment>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            
            {/* Печатная область через Portal - выводится напрямую в body */}
            {createPortal(
              <div id="print-root" style={{display: 'none'}}>
                <div style={{padding: '10mm', fontFamily: 'Arial, sans-serif'}}>
                  <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '15px'}}>
                    <div>
                      <h1 style={{margin: 0, fontSize: '16pt'}}>{routeSheet.task.name}</h1>
                      <p style={{margin: '5px 0 0 0', fontSize: '11pt', color: '#555'}}>
                        К сбору: <strong>{routeSheet.totalToCollect}</strong> шт • {routeSheet.available} позиций
                        {routeSheet.noStockCount > 0 && <span style={{color: 'red', marginLeft: '10px'}}>• Нет в наличии: {routeSheet.noStockCount}</span>}
                      </p>
                    </div>
                    <div style={{textAlign: 'center'}}>
                      <img src={`https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${encodeURIComponent(getLocalUrl(`/route/${activeTask.id}`))}`} alt="QR" style={{width: '70px', height: '70px'}} />
                      <div style={{fontSize: '8pt', color: '#666'}}>📱 Скан</div>
                    </div>
                  </div>
                  
                  <table style={{width: '100%', borderCollapse: 'collapse', fontSize: '10pt'}}>
                    <thead>
                      <tr style={{background: '#eee'}}>
                        <th style={{border: '1px solid #333', padding: '5px', textAlign: 'left', width: '90px'}}>Ячейка</th>
                        <th style={{border: '1px solid #333', padding: '5px', textAlign: 'left'}}>Товар</th>
                        <th style={{border: '1px solid #333', padding: '5px', textAlign: 'center', width: '50px'}}>Кол</th>
                        <th style={{border: '1px solid #333', padding: '5px', textAlign: 'center', width: '35px'}}>✓</th>
                      </tr>
                    </thead>
                    <tbody>
                      {routeSheet.zones.map((zone, zi) => (
                        <React.Fragment key={`pz-${zi}`}>
                          <tr className="rack-header">
                            <td colSpan={4} style={{border: '1px solid #333', padding: '5px', fontWeight: 'bold', background: '#dbeafe'}}>📍 Стеллаж {zone.rack}</td>
                          </tr>
                          {zone.items.map((item, ii) => (
                            <tr key={`pi-${zi}-${ii}`}>
                              <td style={{border: '1px solid #333', padding: '4px', fontFamily: 'monospace', fontSize: '9pt'}}>{item.cell_address ? item.cell_address.replace(/Стеллаж \d+ /i, '').replace(/полка/i, 'п').replace(/ячейка/i, 'яч') : '—'}</td>
                              <td style={{border: '1px solid #333', padding: '4px'}}>
                                <div>{item.name}</div>
                                <div style={{color: '#555', fontSize: '9pt'}}>{item.barcode}</div>
                              </td>
                              <td style={{border: '1px solid #333', padding: '4px', textAlign: 'center', fontWeight: 'bold', fontSize: '12pt'}}>{item.qty_to_collect}</td>
                              <td style={{border: '1px solid #333', padding: '4px', textAlign: 'center'}}>
                                <div style={{width: '14px', height: '14px', border: '2px solid #333', margin: '0 auto'}}></div>
                              </td>
                            </tr>
                          ))}
                        </React.Fragment>
                      ))}
                    </tbody>
                  </table>
                  
                  {routeSheet.noStockCount > 0 && (
                    <div style={{marginTop: '10px', padding: '8px', background: '#fef2f2', border: '1px solid #fca5a5', fontSize: '10pt'}}>
                      <strong style={{color: '#b91c1c'}}>⚠️ Нет на складе:</strong>{' '}
                      <span style={{color: '#dc2626'}}>{routeSheet.noStock.slice(0,5).map(i=>`${i.name} (${i.planned_qty})`).join(', ')}</span>
                    </div>
                  )}
                  
                  <div style={{marginTop: '15px', display: 'flex', justifyContent: 'space-between', fontSize: '10pt', color: '#666'}}>
                    <span>Дата: {new Date().toLocaleDateString('ru')} {new Date().toLocaleTimeString('ru', {hour:'2-digit',minute:'2-digit'})}</span>
                    <span>Собрал: _____________________</span>
                  </div>
                </div>
              </div>,
              document.body
            )}
          </>
        )}


        {/* Marking Modal */}
        {markingModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={()=>setMarkingModal(null)}>
            <div className="bg-white rounded-2xl p-6 max-w-md w-full" onClick={e=>e.stopPropagation()}>
              <h2 className="text-lg font-bold mb-2">Код маркировки (Честный знак)</h2>
              <p className="text-sm text-gray-600 mb-4">Товар: <strong>{markingModal.product}</strong></p>
              <input
                ref={markingRef}
                type="text"
                placeholder="Отсканируйте код маркировки..."
                className="w-full px-4 py-3 rounded-xl text-lg font-mono border-2"
                onKeyDown={e=>{ if(e.key==='Enter'){ submitMarking(e.target.value); e.target.value=''; } }}
                autoFocus
              />
              <div className="mt-4 flex justify-end gap-2">
                <button className="btn-secondary" onClick={()=>setMarkingModal(null)}>Отмена</button>
              </div>
            </div>
          </div>
        )}

        {/* Модальное окно для ввода штрих-кода короба от маркетплейса */}
        {showBoxBarcodeModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full" onClick={e=>e.stopPropagation()}>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Box className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h2 className="text-lg font-bold">Короб #{showBoxBarcodeModal.boxNumber}</h2>
                  <p className="text-sm text-gray-500">Отсканируйте штрих-код короба из ЛК маркетплейса</p>
                </div>
              </div>
              
              <input
                ref={boxBarcodeRef}
                type="text"
                value={boxBarcodeInput}
                onChange={e => setBoxBarcodeInput(e.target.value)}
                placeholder="Штрих-код короба маркетплейса..."
                className="w-full px-4 py-3 rounded-xl text-lg font-mono border-2 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                onKeyDown={e => { if(e.key === 'Enter') handleSaveBoxBarcode(); }}
                autoFocus
              />
              
              <p className="text-xs text-gray-400 mt-2">
                Этот штрих-код будет использоваться при выгрузке в Excel для загрузки в ЛК маркетплейса
              </p>
              
              <div className="mt-4 flex justify-end gap-2">
                <button className="btn-secondary" onClick={handleSkipBoxBarcode}>
                  Пропустить
                </button>
                <button className="btn-primary" onClick={handleSaveBoxBarcode}>
                  {boxBarcodeInput.trim() ? 'Сохранить' : 'Создать без штрих-кода'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Box Contents Modal - Просмотр и редактирование содержимого короба */}
        {showBoxContents && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => { setShowBoxContents(null); setEditingBox(false); setAddProductToBox(false); }}>
            <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col" onClick={e => e.stopPropagation()}>
              {/* Шапка */}
              <div className="p-4 border-b flex justify-between items-center">
                <div>
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    <Box className="w-5 h-5 text-blue-600" />
                    Короб #{showBoxContents.box.number}
                    <span className={`text-sm px-2 py-0.5 rounded-full ${showBoxContents.box.status === 'closed' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'}`}>
                      {showBoxContents.box.status === 'closed' ? 'Закрыт' : 'Открыт'}
                    </span>
                  </h2>
                  <p className="text-sm text-gray-500">Всего: {showBoxContents.items.reduce((s,i) => s + i.quantity, 0)} шт • {showBoxContents.items.length} позиций</p>
                  {/* Штрих-код короба маркетплейса */}
                  {showBoxContents.box.marketplace_barcode && (
                    <p className="text-xs text-blue-600 mt-1">📦 Штрих-код: {showBoxContents.box.marketplace_barcode}</p>
                  )}
                </div>
                <button onClick={() => { setShowBoxContents(null); setEditingBox(false); setAddProductToBox(false); }} className="p-2 hover:bg-gray-100 rounded-lg">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Кнопки действий */}
              <div className="px-4 py-2 border-b bg-gray-50 flex gap-2 flex-wrap">
                {!editingBox ? (
                  <button onClick={() => setEditingBox(true)} className="btn-secondary text-sm flex items-center gap-1">
                    ✏️ Редактировать
                  </button>
                ) : (
                  <button onClick={() => setEditingBox(false)} className="btn-primary text-sm flex items-center gap-1">
                    ✓ Готово
                  </button>
                )}
                {editingBox && (
                  <button onClick={() => setAddProductToBox(true)} className="btn-secondary text-sm flex items-center gap-1">
                    <Plus className="w-4 h-4" /> Добавить товар
                  </button>
                )}
                {showBoxContents.box.status === 'closed' && (
                  <button onClick={() => handleReopenBox(showBoxContents.box.id)} className="btn-secondary text-sm flex items-center gap-1 text-amber-600">
                    🔓 Открыть короб
                  </button>
                )}
              </div>

              {/* Содержимое */}
              <div className="flex-1 overflow-auto p-4">
                {showBoxContents.items.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Box className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                    <p>Короб пуст</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {showBoxContents.items.map(item => (
                      <div key={item.product_id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                        <ProductImage productId={item.product_id} alt={item.name} className="w-12 h-12 rounded-lg flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{item.name}</p>
                          <p className="text-xs text-gray-500">{item.barcode || item.article}</p>
                          {item.marking_codes && <p className="text-xs text-blue-600">🏷 Маркировка: {item.scans_count} шт</p>}
                        </div>
                        
                        {editingBox ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleUpdateBoxItem(item.product_id, Math.max(0, item.quantity - 1))}
                              className="w-8 h-8 rounded-lg bg-white border flex items-center justify-center hover:bg-gray-100"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => {
                                const newVal = parseInt(e.target.value) || 0;
                                handleUpdateBoxItem(item.product_id, Math.max(0, newVal));
                              }}
                              className="w-16 h-8 text-center font-bold border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                              min="0"
                            />
                            <button
                              onClick={() => handleUpdateBoxItem(item.product_id, item.quantity + 1)}
                              className="w-8 h-8 rounded-lg bg-white border flex items-center justify-center hover:bg-gray-100"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Удалить "${item.name}" из короба?`)) {
                                  handleDeleteBoxItem(item.product_id);
                                }
                              }}
                              className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center hover:bg-red-100 ml-1"
                              title="Удалить"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <span className="font-bold text-lg">{item.quantity} шт</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Add Product to Box Modal */}
        {addProductToBox && showBoxContents && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[60] p-4" onClick={() => { setAddProductToBox(false); setSelected(null); setSearch(''); }}>
            <div className="bg-white rounded-2xl max-w-lg w-full max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
              <div className="p-4 border-b">
                <h3 className="font-bold">Добавить товар в короб #{showBoxContents.box.number}</h3>
              </div>
              
              <div className="p-4 border-b">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={search}
                    onChange={e => { setSearch(e.target.value); getProducts({ search: e.target.value, limit: 20 }).then(({ data }) => setProducts(data.products)); }}
                    placeholder="Поиск товара..."
                    className="w-full pl-10 pr-4 py-3 rounded-xl border-2"
                    autoFocus
                  />
                </div>
              </div>
              
              <div className="flex-1 overflow-auto p-4 space-y-2">
                {products.map(p => (
                  <div
                    key={p.id}
                    onClick={() => setSelected(p)}
                    className={`p-3 rounded-xl cursor-pointer flex items-center gap-3 ${selected?.id === p.id ? 'bg-blue-50 border-2 border-blue-400' : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'}`}
                  >
                    <ProductImage productId={p.id} alt={p.name} className="w-10 h-10 rounded-lg" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{p.name}</p>
                      <p className="text-xs text-gray-500">{p.barcode}</p>
                    </div>
                    {selected?.id === p.id && <CheckCircle className="w-5 h-5 text-blue-500" />}
                  </div>
                ))}
              </div>
              
              {selected && (
                <div className="p-4 border-t bg-gray-50">
                  <div className="flex items-center gap-3">
                    <span className="flex-1 text-sm truncate">{selected.name}</span>
                    <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-10 h-10 rounded-lg bg-white border flex items-center justify-center">
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-12 text-center font-bold">{qty}</span>
                    <button onClick={() => setQty(qty + 1)} className="w-10 h-10 rounded-lg bg-white border flex items-center justify-center">
                      <Plus className="w-4 h-4" />
                    </button>
                    <button onClick={() => handleAddProductToBox(selected.id, qty)} className="px-4 py-2 rounded-xl bg-blue-600 text-white font-medium">
                      Добавить
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Completed Task Modal - Результаты завершения с Excel */}
        {completedTask && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl max-w-md w-full p-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-emerald-600" />
                </div>
                <h2 className="text-xl font-bold text-gray-900 mb-2">Поставка завершена!</h2>
                <p className="text-gray-600">{completedTask.message}</p>
                
                {completedTask.demandId && (
                  <p className="text-sm text-emerald-600 mt-2">✓ Отгрузка создана в МойСклад</p>
                )}
                {completedTask.demandError && (
                  <p className="text-sm text-red-600 mt-2">⚠️ Отгрузка: {completedTask.demandError}</p>
                )}
              </div>
              
              <div className="space-y-3 mb-6">
                <p className="text-sm font-medium text-gray-700 text-center">Скачать Excel отчёты:</p>
                
                <button
                  onClick={() => downloadExcel(completedTask.id, 'products')}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-blue-50 text-blue-700 rounded-xl hover:bg-blue-100 transition-colors"
                >
                  <Upload className="w-5 h-5 rotate-180" />
                  <span className="font-medium">Список товаров (артикул, количество)</span>
                </button>
                
                <button
                  onClick={() => downloadExcel(completedTask.id, 'boxes')}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-amber-50 text-amber-700 rounded-xl hover:bg-amber-100 transition-colors"
                >
                  <Box className="w-5 h-5" />
                  <span className="font-medium">Грузовые места (привязка к коробам)</span>
                </button>
              </div>
              
              <button
                onClick={() => setCompletedTask(null)}
                className="w-full py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors"
              >
                Закрыть
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }
  
  return (
    <div className="max-w-5xl mx-auto px-4 py-4">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h1 className="text-xl font-bold">Сборка / Упаковка</h1>
        <div className="flex gap-2">
          <button onClick={()=>setShowSettings(true)} className="btn-secondary p-2" title="Настройки МойСклад">
            ⚙️
          </button>
          <button onClick={()=>setShowManual(true)} className="btn-secondary flex items-center gap-2"><Plus className="w-5 h-5"/> Вручную</button>
          <button onClick={()=>setShowUpload(true)} className="btn-primary flex items-center gap-2"><Upload className="w-5 h-5"/> Excel</button>
        </div>
      </div>

      {/* Модальное окно настроек МойСклад */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowSettings(false)}>
          <div className="bg-white rounded-2xl p-6 max-w-md w-full" onClick={e => e.stopPropagation()}>
            <h2 className="text-lg font-bold mb-4">Настройки МойСклад</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Организация</label>
                <select
                  value={msSettings.organizationId || ''}
                  onChange={(e) => saveMsSettings({ organizationId: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg"
                >
                  <option value="">Выберите организацию</option>
                  {organizations.map(org => (
                    <option key={org.id} value={org.id}>{org.name}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Склад</label>
                <select
                  value={msSettings.storeId || ''}
                  onChange={(e) => saveMsSettings({ storeId: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg"
                >
                  <option value="">Выберите склад</option>
                  {stores.map(store => (
                    <option key={store.id} value={store.id}>{store.name}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-blue-50 rounded-lg text-sm text-blue-700">
              <p className="font-medium">Как это работает:</p>
              <p className="mt-1">1. При загрузке Excel выберите контрагента</p>
              <p>2. Автоматически создаются: Заказ покупателя + Отгрузка (непроведённая)</p>
              <p>3. В ТСД появится задание на выемку с ячейками</p>
              <p>4. После сборки нажмите "Завершить" — отгрузка проведётся, остатки спишутся</p>
            </div>
            
            <button
              onClick={() => setShowSettings(false)}
              className="w-full mt-4 py-2 bg-gray-100 rounded-lg font-medium hover:bg-gray-200"
            >
              Закрыть
            </button>
          </div>
        </div>
      )}
      
      {showUpload&&(
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={()=>{setShowUpload(false);setSelectedCounterparty(null);setCounterpartySearch('');}}>
          <div className="bg-white rounded-2xl p-6 max-w-md w-full" onClick={e=>e.stopPropagation()}>
            <h2 className="text-lg font-bold mb-2">Загрузка Excel</h2>
            <p className="text-sm text-gray-500 mb-4">Колонки: Barcode/Артикул + Количество</p>
            
            {/* Выбор контрагента */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Контрагент (покупатель)</label>
              <div className="relative">
                <input
                  type="text"
                  value={counterpartySearch}
                  onChange={(e) => {
                    setCounterpartySearch(e.target.value);
                    loadCounterparties(e.target.value);
                  }}
                  placeholder="Поиск контрагента..."
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                {counterparties.length > 0 && counterpartySearch && !selectedCounterparty && (
                  <div className="absolute z-10 w-full mt-1 bg-white border rounded-lg shadow-lg max-h-40 overflow-auto">
                    {counterparties.slice(0, 10).map(cp => (
                      <div
                        key={cp.id}
                        onClick={() => {
                          setSelectedCounterparty(cp);
                          setCounterpartySearch(cp.name);
                        }}
                        className="px-3 py-2 hover:bg-blue-50 cursor-pointer text-sm"
                      >
                        {cp.name}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              {selectedCounterparty && (
                <div className="mt-2 flex items-center gap-2 text-sm text-emerald-600">
                  <CheckCircle className="w-4 h-4" />
                  <span>{selectedCounterparty.name}</span>
                  <button onClick={() => {setSelectedCounterparty(null); setCounterpartySearch('');}} className="ml-auto text-gray-400 hover:text-red-500">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
            
            <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" onChange={handleUpload} className="hidden"/>
            <button onClick={()=>fileRef.current?.click()} className="w-full btn-primary py-3">Выбрать файл</button>
            
            {!msSettings.organizationId && (
              <p className="mt-3 text-xs text-amber-600 flex items-center gap-1">
                <AlertTriangle className="w-4 h-4" />
                Настройте организацию и склад в настройках
              </p>
            )}
          </div>
        </div>
      )}

      {showManual&&(
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={()=>{setShowManual(false);setManualItems([]);setSelected(null);}}>
          <div className="bg-white rounded-2xl p-5 max-w-lg w-full max-h-[85vh] flex flex-col" onClick={e=>e.stopPropagation()}>
            <h2 className="text-lg font-bold mb-4">Добавить товары вручную</h2>
            
            <div className="relative mb-3">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"/>
              <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Поиск товара..." className="w-full pl-10 pr-4 py-3 rounded-xl border-2"/>
            </div>
            
            <div className="flex-1 overflow-auto space-y-2 mb-3 min-h-[150px]">
              {products.map(p=>(
                <div key={p.id} onClick={()=>setSelected(p)} className={`p-3 rounded-xl cursor-pointer flex items-center gap-3 ${selected?.id===p.id?'bg-blue-50 border-2 border-blue-400':'bg-gray-50 border-2 border-transparent'}`}>
                  <Package className="w-10 h-10 text-gray-400"/>
                  <div className="flex-1"><p className="font-medium text-sm truncate">{p.name}</p><p className="text-xs text-gray-500">{p.barcode} • Остаток: {p.stock||0}</p></div>
                  {selected?.id===p.id&&<CheckCircle className="w-5 h-5 text-blue-500"/>}
                </div>
              ))}
            </div>
            
            {selected&&(
              <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl mb-3">
                <span className="flex-1 text-sm truncate">{selected.name}</span>
                <button onClick={()=>setQty(Math.max(1,qty-1))} className="w-8 h-8 rounded-lg bg-white border flex items-center justify-center"><Minus className="w-4 h-4"/></button>
                <span className="w-10 text-center font-bold">{qty}</span>
                <button onClick={()=>setQty(qty+1)} className="w-8 h-8 rounded-lg bg-white border flex items-center justify-center"><Plus className="w-4 h-4"/></button>
                <button onClick={handleAddManualItem} className="px-4 py-2 rounded-xl bg-blue-500 text-white font-medium">+</button>
              </div>
            )}
            
            {manualItems.length>0&&(
              <div className="border-t pt-3 mb-3">
                <p className="text-sm font-medium mb-2">Добавлено: {manualItems.length} поз.</p>
                <div className="space-y-1 max-h-[100px] overflow-auto">
                  {manualItems.map((item,i)=>(
                    <div key={i} className="flex justify-between text-sm bg-gray-50 px-3 py-1 rounded">
                      <span className="truncate">{item.product.name}</span>
                      <span className="font-bold">{item.quantity}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <button onClick={handleCreateManualTask} disabled={manualItems.length===0} className={`w-full py-3 rounded-xl font-medium ${manualItems.length>0?'bg-emerald-500 text-white':'bg-gray-100 text-gray-400'}`}>
              Создать задачу ({manualItems.reduce((s,i)=>s+i.quantity,0)} шт)
            </button>
          </div>
        </div>
      )}
      
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tasks.map(t=>{
          const progress = (t.total_items||0)>0?((t.scanned_items||0)/(t.total_items||0))*100:0;
          return (
            <div key={t.id} className={`card ${t.status==='completed'?'opacity-80':''}`}>
              <div onClick={()=>loadTask(t.id)} className="cursor-pointer">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold">{t.name}</h3>
                  <span className={`text-xs px-2 py-1 rounded-full ${t.status==='completed'?'bg-emerald-100 text-emerald-700':t.status==='cancelled'?'bg-gray-100 text-gray-500':'bg-blue-100 text-blue-700'}`}>
                    {t.status==='completed'?'Готово':t.status==='cancelled'?'Отменена':'В работе'}
                  </span>
                </div>
                <p className="text-sm text-gray-500 mb-2">{t.scanned_items||0} / {t.total_items||0} шт</p>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className={`h-full ${t.status==='completed'?'bg-emerald-500':'bg-blue-500'}`} style={{width:`${Math.min(progress,100)}%`}}/>
                </div>
              </div>
              
              {/* Кнопки Excel для завершённых задач */}
              {t.status === 'completed' && (
                <div className="flex gap-2 mt-3 pt-3 border-t">
                  <button
                    onClick={(e) => { e.stopPropagation(); downloadExcel(t.id, 'products'); }}
                    className="flex-1 text-xs py-1.5 px-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 flex items-center justify-center gap-1"
                  >
                    📋 Товары
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); downloadExcel(t.id, 'boxes'); }}
                    className="flex-1 text-xs py-1.5 px-2 bg-amber-50 text-amber-600 rounded-lg hover:bg-amber-100 flex items-center justify-center gap-1"
                  >
                    📦 Короба
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      {tasks.length===0&&(
        <div className="text-center py-12 text-gray-500">
          <PackageCheck className="w-12 h-12 mx-auto mb-3 text-gray-300"/>
          <p>Нет задач на сборку</p>
          <p className="text-sm mt-2">Загрузите Excel или добавьте товары вручную</p>
        </div>
      )}
    </div>
  );
}

function ReceivingPage({ showToast }) {
  const [orders, setOrders] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [activeSession, setActiveSession] = useState(null);
  const [sessionData, setSessionData] = useState(null);
  const [showOrders, setShowOrders] = useState(false);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showDefectModal, setShowDefectModal] = useState(null);
  const [showUndoConfirm, setShowUndoConfirm] = useState(false);
  const [defectQty, setDefectQty] = useState(0);
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [qty, setQty] = useState(1);
  const [canUndo, setCanUndo] = useState(false);
  const [zoomedImage, setZoomedImage] = useState(null); // Для увеличенного изображения
  const [lastScanTime, setLastScanTime] = useState(0); // Таймаут сканирования
  const SCAN_TIMEOUT = 500; // 0.5 секунды
  const scanRef = useRef(null);

  const loadOrders = () => api.get('/receiving/orders').then(({data})=>setOrders(data)).catch(()=>{});
  const loadSessions = () => api.get('/receiving/sessions').then(({data})=>setSessions(data));
  const loadSession = async (id) => { try { const {data} = await api.get(`/receiving/sessions/${id}`); setSessionData(data); setActiveSession(id); setCanUndo(!!data.last_scan_item_id); } catch(err) { showToast('Ошибка','error'); }};

  useEffect(() => { loadSessions(); loadOrders(); }, []);
  useEffect(() => { if (showAddProduct) getProducts({search,limit:50}).then(({data})=>setProducts(data.products)); }, [showAddProduct, search]);
  useEffect(() => {
    if (!activeSession || sessionData?.status !== 'active') return;
    const focus = () => { if (!showAddProduct && !showDefectModal && !showUndoConfirm && !zoomedImage) scanRef.current?.focus(); };
    focus();
    const onClick = (e) => { if (e.target.tagName!=='INPUT' && e.target.tagName!=='BUTTON' && !e.target.closest('button')) setTimeout(focus,50); };
    const onKey = () => { if (!showAddProduct && !showDefectModal && !showUndoConfirm && !zoomedImage && document.activeElement!==scanRef.current) scanRef.current?.focus(); };
    document.addEventListener('click', onClick);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('click', onClick); document.removeEventListener('keydown', onKey); };
  }, [activeSession, sessionData, showAddProduct, showDefectModal, showUndoConfirm, zoomedImage]);

  const handleCreateSession = async (orderId=null) => { try { const {data} = await api.post('/receiving/sessions',{purchaseOrderId:orderId}); showToast('Создано','success'); setShowOrders(false); loadSessions(); loadSession(data.sessionId); } catch(err) { showToast('Ошибка','error'); }};
  
  const handleScan = async (barcode) => { 
    if (!barcode.trim()) return; 
    // Защита от двойного сканирования (0.5 сек)
    const now = Date.now();
    if (now - lastScanTime < SCAN_TIMEOUT) {
      console.log('Scan ignored (timeout)');
      return;
    }
    setLastScanTime(now);
    
    try { 
      const {data} = await api.post(`/receiving/sessions/${activeSession}/scan`,{barcode:barcode.trim()}); 
      if(data.isExtra){playSound('warning');showToast(`⚠️ ПЕРЕСОРТ: ${data.product} +${data.received}`,'error');}
      else{playSound('success');showToast(`✓ ${data.product}: ${data.received}/${data.ordered}`,'success');} 
      setCanUndo(true); 
      loadSession(activeSession); 
    } catch(err) { 
      playSound('error'); 
      showToast(err.response?.data?.error||'Не найден','error'); 
    }
  };
  
  const handleUndo = async () => { try { const {data} = await api.post(`/receiving/sessions/${activeSession}/undo`); playSound('warning'); showToast(data.message,'success'); setCanUndo(false); setShowUndoConfirm(false); loadSession(activeSession); } catch(err) { showToast('Ошибка','error'); }};
  const handleAddProduct = async () => { if (!selected) return; try { await api.post(`/receiving/sessions/${activeSession}/items`,{productId:selected.id,quantity:qty,isExtra:true}); playSound('warning'); showToast(`Пересорт: ${selected.name} +${qty}`,'success'); setShowAddProduct(false); setSelected(null); setQty(1); setSearch(''); loadSession(activeSession); } catch(err) { showToast('Ошибка','error'); }};
  const handleSetDefect = async () => { if (!showDefectModal) return; try { await api.post(`/receiving/sessions/${activeSession}/items/${showDefectModal.id}/defect`,{defect_qty:defectQty}); showToast(`Брак: ${defectQty} шт`,'success'); setShowDefectModal(null); setDefectQty(0); loadSession(activeSession); } catch(err) { showToast('Ошибка','error'); }};
  const handleComplete = async () => { try { const {data} = await api.post(`/receiving/sessions/${activeSession}/complete`); playSound('complete'); showToast(data.message,'success'); setActiveSession(null); setSessionData(null); loadSessions(); } catch(err) { showToast(err.response?.data?.message||'Ошибка','error'); }};

  if (activeSession && sessionData) {
    const items = sessionData.items || [];
    const orderedItems = items.filter(i => !i.is_extra);
    const extraItems = items.filter(i => i.is_extra);
    const defectItems = items.filter(i => i.defect_qty > 0);
    const totalReceived = items.reduce((s,i) => s + (i.received_qty||0), 0);
    const totalDefects = items.reduce((s,i) => s + (i.defect_qty||0), 0);
    const totalOrdered = sessionData.total_ordered || 0;
    const progress = totalOrdered > 0 ? Math.min((totalReceived/totalOrdered)*100, 100) : 0;

    return (
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="bg-white rounded-2xl shadow-sm border p-4 mb-4">
          <div className="flex items-center gap-4 flex-wrap">
            <button onClick={()=>{setActiveSession(null);setSessionData(null);}} className="btn-secondary p-2.5 rounded-xl"><ArrowLeft className="w-5 h-5"/></button>
            <div className="flex-1 min-w-[200px]">
              <h2 className="font-bold text-xl">{sessionData.name}</h2>
              <div className="flex items-center gap-3 text-sm text-gray-500 mt-1 flex-wrap">
                {sessionData.supplier_name && <span className="flex items-center gap-1"><Truck className="w-4 h-4"/> {sessionData.supplier_name}</span>}
                <span>Принято: <strong>{totalReceived}</strong>{totalOrdered>0&&` / ${totalOrdered}`}</span>
                {totalDefects>0 && <span className="text-red-600">Брак: <strong>{totalDefects}</strong></span>}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {canUndo && sessionData.status==='active' && <button onClick={()=>setShowUndoConfirm(true)} className="px-4 py-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 font-medium text-sm">↩ Отменить</button>}
              {sessionData.status==='active' && <button onClick={handleComplete} disabled={totalReceived===0} className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium ${totalReceived>0?'bg-emerald-500 text-white hover:bg-emerald-600':'bg-gray-100 text-gray-400 cursor-not-allowed'}`}><CheckCircle className="w-5 h-5"/> Завершить приёмку</button>}
            </div>
          </div>
          {totalOrdered>0 && <div className="mt-4"><div className="flex justify-between text-sm mb-1"><span className="text-gray-500">Прогресс</span><span className="font-bold text-emerald-600">{Math.round(progress)}%</span></div><div className="h-2 bg-gray-100 rounded-full overflow-hidden"><div className="h-full bg-emerald-500" style={{width:`${progress}%`}}/></div></div>}
        </div>

        {sessionData.status==='active' && (
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl p-5 mb-4 shadow-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-white"><div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"><Scan className="w-5 h-5"/></div><div><span className="font-semibold text-lg">Сканирование</span><p className="text-blue-100 text-xs">Автофокус • Звук</p></div></div>
              <button onClick={()=>setShowAddProduct(true)} className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"><Plus className="w-4 h-4"/> Добавить излишки</button>
            </div>
            <input ref={scanRef} type="text" placeholder="Отсканируйте штрихкод..." className="w-full px-5 py-4 rounded-xl text-xl font-mono bg-white focus:ring-4 focus:ring-white/30" autoFocus onKeyDown={e=>{if(e.key==='Enter'&&e.target.value){handleScan(e.target.value);e.target.value='';}}}/>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
              <div className="bg-gray-50 px-4 py-3 border-b"><h3 className="font-semibold flex items-center gap-2"><Package className="w-5 h-5 text-blue-600"/> Ожидаемые <span className="bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full">{orderedItems.length}</span></h3></div>
              <div className="divide-y max-h-[500px] overflow-auto">
                {orderedItems.length===0 ? <div className="p-8 text-center text-gray-400"><Package className="w-12 h-12 mx-auto mb-2 opacity-50"/><p>Сканируйте товары</p></div> : orderedItems.map(item=>{
                  const isComplete = item.received_qty >= item.ordered_qty;
                  const hasDefect = item.defect_qty > 0;
                  return (
                    <div key={item.id} className={`p-4 ${hasDefect?'bg-red-50':isComplete?'bg-emerald-50':''}`}>
                      <div className="flex gap-4">
                        <ProductImage 
                          productId={item.product_id}
                          alt={item.name}
                          className="w-20 h-20 rounded-xl flex-shrink-0 border"
                          clickable={!!item.product_id}
                          onClick={() => item.product_id && setZoomedImage({ productId: item.product_id, alt: item.name })}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm mb-1 line-clamp-2">{item.name}</p>
                          {item.barcode && <div className="inline-block bg-white rounded-lg px-3 py-1.5 border shadow-sm"><BarcodeSVG value={item.barcode} height={32}/><p className="text-xs text-center text-gray-500 font-mono mt-1">{item.barcode}</p></div>}
                          {hasDefect && <div className="mt-2 inline-flex items-center gap-1 bg-red-100 text-red-700 text-xs px-2 py-1 rounded-full"><AlertTriangle className="w-3 h-3"/> Брак: {item.defect_qty}</div>}
                        </div>
                        <div className="flex flex-col items-end justify-between">
                          <div className={`text-2xl font-bold ${hasDefect?'text-red-600':isComplete?'text-emerald-600':'text-gray-800'}`}>{item.received_qty||0} <span className="text-gray-400 font-normal">/</span> {item.ordered_qty}</div>
                          {sessionData.status==='active' && <button onClick={()=>{setShowDefectModal(item);setDefectQty(item.defect_qty||0);}} className={`text-xs px-3 py-1.5 rounded-lg font-medium ${hasDefect?'bg-red-100 text-red-700':'bg-gray-100 text-gray-600 hover:bg-red-50 hover:text-red-600'}`}>{hasDefect?`Брак: ${item.defect_qty}`:'+ Брак'}</button>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-amber-50 rounded-2xl border-2 border-amber-200 overflow-hidden">
              <div className="bg-amber-100 px-4 py-3 border-b border-amber-200"><h3 className="font-semibold text-amber-800 flex items-center gap-2"><AlertTriangle className="w-5 h-5"/> Пересорт {extraItems.length>0&&<span className="bg-amber-200 text-xs px-2 py-0.5 rounded-full">{extraItems.length}</span>}</h3><p className="text-xs text-amber-600 mt-0.5">→ Оприходование</p></div>
              <div className="divide-y divide-amber-200 max-h-[250px] overflow-auto">
                {extraItems.length===0 ? <div className="p-6 text-center text-amber-600/60"><p className="text-sm">Нет излишков</p></div> : extraItems.map(item=>(
                  <div key={item.id} className="p-3 flex items-center gap-3">
                    <ProductImage 
                      productId={item.product_id}
                      alt={item.name}
                      className="w-12 h-12 rounded-lg flex-shrink-0"
                      clickable={!!item.product_id}
                      onClick={() => item.product_id && setZoomedImage({ productId: item.product_id, alt: item.name })}
                    />
                    <div className="flex-1 min-w-0"><p className="font-medium text-sm truncate text-amber-900">{item.name}</p><p className="text-xs text-amber-600 font-mono">{item.barcode||item.article}</p></div>
                    <div className="text-xl font-bold text-amber-600">+{item.received_qty}</div>
                  </div>
                ))}
              </div>
            </div>

            {defectItems.length>0 && (
              <div className="bg-red-50 rounded-2xl border-2 border-red-200 overflow-hidden">
                <div className="bg-red-100 px-4 py-3 border-b border-red-200"><h3 className="font-semibold text-red-800 flex items-center gap-2"><AlertTriangle className="w-5 h-5"/> Брак <span className="bg-red-200 text-xs px-2 py-0.5 rounded-full">{totalDefects}</span></h3></div>
                <div className="p-3 space-y-2">{defectItems.map(item=><div key={item.id} className="flex justify-between items-center bg-white/50 rounded-lg px-3 py-2"><span className="text-sm text-red-800">{item.article||item.name}</span><span className="font-bold text-red-700">{item.defect_qty}</span></div>)}</div>
              </div>
            )}

            <div className="bg-white rounded-2xl border p-4">
              <h3 className="font-semibold text-gray-700 mb-3">Итого</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-gray-500">Ожидалось:</span><span>{totalOrdered}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Принято:</span><span className="text-emerald-600">{orderedItems.reduce((s,i)=>s+(i.received_qty||0),0)}</span></div>
                {extraItems.length>0 && <div className="flex justify-between"><span className="text-gray-500">Излишки:</span><span className="text-amber-600">+{extraItems.reduce((s,i)=>s+(i.received_qty||0),0)}</span></div>}
                {totalDefects>0 && <div className="flex justify-between"><span className="text-gray-500">Брак:</span><span className="text-red-600">{totalDefects}</span></div>}
              </div>
            </div>
          </div>
        </div>

        {showUndoConfirm && <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={()=>setShowUndoConfirm(false)}><div className="bg-white rounded-2xl p-6 max-w-sm w-full" onClick={e=>e.stopPropagation()}><div className="text-center mb-4"><div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4"><AlertTriangle className="w-8 h-8 text-amber-600"/></div><h2 className="text-lg font-bold">Отменить последнее сканирование?</h2></div><div className="flex gap-3"><button onClick={()=>setShowUndoConfirm(false)} className="flex-1 py-3 rounded-xl border-2 font-medium hover:bg-gray-50">Нет</button><button onClick={handleUndo} className="flex-1 py-3 rounded-xl bg-amber-500 text-white font-medium">Да</button></div></div></div>}

        {showDefectModal && <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={()=>setShowDefectModal(null)}><div className="bg-white rounded-2xl p-6 max-w-sm w-full" onClick={e=>e.stopPropagation()}><div className="flex items-center gap-3 mb-4"><div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center"><AlertTriangle className="w-6 h-6 text-red-600"/></div><div><h2 className="text-lg font-bold">Указать брак</h2><p className="text-sm text-gray-500">{showDefectModal.article||'—'}</p></div></div><p className="text-sm text-gray-600 mb-4">{showDefectModal.name}</p><div className="flex items-center justify-center gap-4 mb-4 py-4 bg-gray-50 rounded-xl"><button onClick={()=>setDefectQty(Math.max(0,defectQty-1))} className="w-12 h-12 rounded-xl bg-white border-2 flex items-center justify-center"><Minus className="w-5 h-5"/></button><span className="text-4xl font-bold text-red-600 w-20 text-center">{defectQty}</span><button onClick={()=>setDefectQty(defectQty+1)} className="w-12 h-12 rounded-xl bg-white border-2 flex items-center justify-center"><Plus className="w-5 h-5"/></button></div><div className="flex gap-3"><button onClick={()=>setShowDefectModal(null)} className="flex-1 py-3 rounded-xl border-2 font-medium">Отмена</button><button onClick={handleSetDefect} className="flex-1 py-3 rounded-xl bg-red-600 text-white font-medium">Сохранить</button></div></div></div>}

        {showAddProduct && <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={()=>setShowAddProduct(false)}><div className="bg-white rounded-2xl p-5 max-w-lg w-full max-h-[85vh] flex flex-col" onClick={e=>e.stopPropagation()}><div className="flex items-center gap-3 mb-4"><div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center"><Plus className="w-6 h-6 text-amber-600"/></div><div><h2 className="text-lg font-bold">Добавить излишки</h2><p className="text-sm text-gray-500">Сканируйте или найдите</p></div></div><div className="bg-amber-50 rounded-xl p-3 mb-3 border border-amber-200"><div className="flex items-center gap-2 mb-2"><Scan className="w-4 h-4 text-amber-600"/><span className="text-sm font-medium text-amber-700">Сканирование</span></div><input type="text" placeholder="Штрихкод..." className="w-full px-3 py-2 rounded-lg border border-amber-300 text-sm font-mono" autoFocus onKeyDown={async(e)=>{if(e.key==='Enter'&&e.target.value){const bc=e.target.value.trim();e.target.value='';try{const{data}=await api.post(`/receiving/sessions/${activeSession}/scan`,{barcode:bc});playSound('warning');showToast(`Пересорт: ${data.product}`,'success');setCanUndo(true);loadSession(activeSession);}catch(err){playSound('error');showToast('Не найден','error');}}}}/></div><div className="relative mb-3"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"/><input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Или найдите..." className="w-full pl-10 pr-4 py-3 rounded-xl border-2"/></div><div className="flex-1 overflow-auto space-y-2 mb-3">{products.map(p=>(<div key={p.id} onClick={()=>setSelected(p)} className={`p-3 rounded-xl cursor-pointer flex items-center gap-3 ${selected?.id===p.id?'bg-amber-50 border-2 border-amber-400':'bg-gray-50 border-2 border-transparent'}`}><Package className="w-10 h-10 text-gray-400"/><div className="flex-1"><p className="font-medium text-sm truncate">{p.name}</p><p className="text-xs text-gray-500">{p.barcode}</p></div>{selected?.id===p.id&&<CheckCircle className="w-5 h-5 text-amber-500"/>}</div>))}</div>{selected&&<div className="flex items-center gap-3 p-4 bg-amber-50 rounded-xl border-2 border-amber-200"><span className="flex-1 text-sm truncate">{selected.name}</span><button onClick={()=>setQty(Math.max(1,qty-1))} className="w-10 h-10 rounded-lg bg-white border flex items-center justify-center"><Minus className="w-4 h-4"/></button><span className="w-12 text-center font-bold">{qty}</span><button onClick={()=>setQty(qty+1)} className="w-10 h-10 rounded-lg bg-white border flex items-center justify-center"><Plus className="w-4 h-4"/></button><button onClick={handleAddProduct} className="px-5 py-2.5 rounded-xl bg-amber-500 text-white font-medium">Добавить</button></div>}</div></div>}

        {/* Модальное окно для увеличенного изображения */}
        {zoomedImage && (
          <ImageModal 
            productId={zoomedImage.productId} 
            alt={zoomedImage.alt} 
            onClose={() => setZoomedImage(null)} 
          />
        )}
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-4">
      <div className="flex items-center justify-between mb-6"><h1 className="text-2xl font-bold">Приёмка</h1><div className="flex gap-2">{orders.length>0&&<button onClick={()=>setShowOrders(true)} className="btn-secondary flex items-center gap-2"><Truck className="w-5 h-5"/> Из заказа ({orders.length})</button>}<button onClick={()=>handleCreateSession()} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5"/> Новая</button></div></div>
      {showOrders && <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={()=>setShowOrders(false)}><div className="bg-white rounded-2xl p-5 max-w-lg w-full max-h-[80vh] flex flex-col" onClick={e=>e.stopPropagation()}><h2 className="text-xl font-bold mb-4">Выберите заказ</h2><div className="flex-1 overflow-auto space-y-2">{orders.map(o=>(<div key={o.id} onClick={()=>handleCreateSession(o.id)} className="p-4 rounded-xl bg-gray-50 hover:bg-blue-50 cursor-pointer border-2 border-transparent hover:border-blue-400"><div className="flex justify-between mb-1"><p className="font-semibold">{o.name}</p><span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">{o.items_count}</span></div><p className="text-sm text-gray-600">{o.supplier_name}</p></div>))}{orders.length===0&&<p className="text-center py-8 text-gray-500">Нет заказов</p>}</div></div></div>}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">{sessions.map(s=>{const p=s.total_ordered>0?(s.total_received/s.total_ordered)*100:0;return(<div key={s.id} onClick={()=>loadSession(s.id)} className={`bg-white rounded-2xl border-2 p-4 cursor-pointer hover:shadow-lg ${s.status==='completed'?'opacity-60':''}`}><div className="flex justify-between items-start mb-3"><div><h3 className="font-semibold">{s.name}</h3>{s.supplier_name&&<p className="text-sm text-gray-500">{s.supplier_name}</p>}</div><span className={`text-xs px-2.5 py-1 rounded-full ${s.status==='active'?'bg-blue-100 text-blue-700':'bg-emerald-100 text-emerald-700'}`}>{s.status==='active'?'Активна':'Завершена'}</span></div><p className="text-sm text-gray-500 mb-3">{s.total_received||0}/{s.total_ordered||0}</p>{s.total_ordered>0&&<div className="h-1.5 bg-gray-100 rounded-full overflow-hidden"><div className={`h-full ${s.status==='completed'?'bg-emerald-500':'bg-blue-500'}`} style={{width:`${Math.min(p,100)}%`}}/></div>}</div>);})}</div>
      {sessions.length===0&&<div className="text-center py-16 text-gray-500"><Truck className="w-16 h-16 mx-auto mb-4 text-gray-300"/><p className="text-lg">Нет сессий</p></div>}
    </div>
  );
}

// Страница маршрутного листа для мобильного просмотра (по QR-коду)
function RouteSheetPage({ taskId }) {
  const [routeSheet, setRouteSheet] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadRouteSheet = async () => {
      try {
        setLoading(true);
        const { data } = await api.get(`/packing/tasks/${taskId}/route-sheet`);
        setRouteSheet(data);
      } catch (err) {
        setError(err.response?.data?.error || 'Ошибка загрузки');
      } finally {
        setLoading(false);
      }
    };
    if (taskId) loadRouteSheet();
  }, [taskId]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500">Загрузка маршрутного листа...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
          <p className="text-red-600 font-medium">{error}</p>
        </div>
      </div>
    );
  }

  if (!routeSheet) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Шапка */}
      <div className="bg-blue-600 text-white p-4 sticky top-0 z-10">
        <h1 className="font-bold text-lg">{routeSheet.task.name}</h1>
        <p className="text-blue-100 text-sm">
          К сбору: {routeSheet.totalToCollect} шт • {routeSheet.available} позиций
        </p>
      </div>

      {/* Нет на складе */}
      {routeSheet.noStockCount > 0 && (
        <div className="bg-red-50 border-b border-red-200 p-3">
          <p className="text-red-700 font-medium text-sm">⚠️ Нет на складе: {routeSheet.noStockCount} поз.</p>
        </div>
      )}

      {/* Список по стеллажам */}
      <div className="p-2">
        {routeSheet.zones.map((zone) => (
          <div key={zone.rack} className="mb-3">
            <div className="bg-blue-100 text-blue-800 px-3 py-2 rounded-t-lg font-bold sticky top-16 z-5">
              📍 Стеллаж {zone.rack}
            </div>
            <div className="bg-white rounded-b-lg border border-t-0 divide-y">
              {zone.items.map(item => (
                <div key={item.id} className="p-3 flex items-center gap-3">
                  <div className="bg-gray-100 px-2 py-1 rounded text-xs font-mono min-w-[70px] text-center">
                    {item.cell_address ? item.cell_address.replace(/Стеллаж \d+ /i, '').replace(/полка/i, 'п').replace(/ячейка/i, 'яч') : '—'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium line-clamp-2">{item.name}</p>
                    <p className="text-xs text-gray-400">{item.barcode}</p>
                  </div>
                  <div className="text-xl font-bold text-blue-600 min-w-[40px] text-right">
                    {item.qty_to_collect}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Итого */}
      <div className="bg-white border-t p-4 sticky bottom-0">
        <div className="flex justify-between items-center">
          <span className="text-gray-500">Всего к сбору:</span>
          <span className="text-2xl font-bold text-blue-600">{routeSheet.totalToCollect} шт</span>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState('products');
  const [toast, setToast] = useState(null);
  const [routeTaskId, setRouteTaskId] = useState(null);
  const sync = useSync();
  const showToast = (message, type='info') => setToast({message,type});
  
  // Проверяем URL для маршрутного листа
  useEffect(() => {
    const path = window.location.pathname;
    const match = path.match(/\/route\/(\d+)/);
    if (match) {
      setRouteTaskId(match[1]);
    }
  }, []);
  
  // Если это страница маршрутного листа — показываем только её
  if (routeTaskId) {
    return <RouteSheetPage taskId={routeTaskId} />;
  }
  
  return (
    <div className="min-h-screen pb-16">
      <PrintStyles />
      <Header page={page} setPage={setPage} sync={sync}/>
      {page==='products'&&<ProductsPage showToast={showToast}/>}
      {page==='packing'&&<PackingPage showToast={showToast}/>}
      {page==='receiving'&&<ReceivingPage showToast={showToast}/>}
      {toast&&<Toast {...toast} onClose={()=>setToast(null)}/>}
    </div>
  );
}
