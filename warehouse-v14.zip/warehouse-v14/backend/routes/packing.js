import { Router } from 'express';
import multer from 'multer';
import * as XLSX from 'xlsx';
import { getDb, logAction } from '../database.js';
import { getMoySkladService } from '../services/moysklad.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });

// Получение списка задач
router.get('/tasks', async (req, res) => {
  try {
    const db = await getDb();
    const tasks = db.prepare(`
      SELECT t.*, 
        (SELECT COUNT(*) FROM packing_task_items WHERE task_id = t.id) as items_count,
        (SELECT SUM(planned_qty) FROM packing_task_items WHERE task_id = t.id) as total_items,
        (SELECT SUM(scanned_qty) FROM packing_task_items WHERE task_id = t.id) as scanned_items
      FROM packing_tasks t
      ORDER BY t.created_at DESC
    `).all();

    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Получение задачи с деталями
router.get('/tasks/:id', async (req, res) => {
  try {
    const db = await getDb();
    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(req.params.id);
    
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }

    const items = db.prepare(`
      SELECT pti.*, p.name, p.barcode, p.article, p.image_url, p.stock, p.cell_address,
             p.requires_marking, p.meta_href, p.price
      FROM packing_task_items pti
      JOIN products p ON p.id = pti.product_id
      WHERE pti.task_id = ?
      ORDER BY p.cell_address, p.name
    `).all(req.params.id);

    const totalPlanned = items.reduce((s, i) => s + i.planned_qty, 0);
    const totalScanned = items.reduce((s, i) => s + i.scanned_qty, 0);

    res.json({ 
      task: { ...task, total_items: totalPlanned, scanned_items: totalScanned }, 
      items
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Загрузка Excel файла
router.post('/tasks/upload', upload.single('file'), async (req, res) => {
  try {
    const db = await getDb();
    
    if (!req.file) {
      return res.status(400).json({ error: 'Файл не загружен' });
    }

    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const data = XLSX.utils.sheet_to_json(sheet);

    if (data.length === 0) {
      return res.status(400).json({ error: 'Файл пустой' });
    }

    const items = [];
    const errors = [];
    const notFound = [];

    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      
      const barcode = row.Barcode || row.barcode || row['Баркод'] || row['ШтрихКод'] || row['штрихкод'] || row['Штрих-код'] || '';
      const sku = row.SKU || row.sku || row['Артикул'] || row['артикул'] || row.Article || row.article || '';
      const name = row.Name || row.name || row['Наименование'] || row['наименование'] || row['Товар'] || '';
      const quantity = Number(row.Quantity || row.quantity || row['Количество'] || row['количество'] || row.Qty || 1);

      if (!barcode && !sku && !name) continue;
      if (!quantity || quantity <= 0) continue;

      let product = null;
      if (barcode) product = db.prepare('SELECT * FROM products WHERE barcode = ?').get(String(barcode).trim());
      if (!product && sku) product = db.prepare('SELECT * FROM products WHERE sku = ? OR article = ?').get(String(sku).trim(), String(sku).trim());
      if (!product && name) product = db.prepare('SELECT * FROM products WHERE LOWER(name) LIKE ?').get(`%${String(name).toLowerCase().trim()}%`);

      if (!product) {
        notFound.push({ row: i + 2, barcode, sku, name, quantity });
        continue;
      }

      items.push({ product, quantity, available: product.stock || 0 });
    }

    if (items.length === 0) {
      return res.status(400).json({ error: 'Не найдено товаров', notFound });
    }

    const taskName = `Сборка ${new Date().toLocaleDateString('ru')} ${new Date().toLocaleTimeString('ru', {hour: '2-digit', minute: '2-digit'})}`;
    const totalQty = items.reduce((sum, i) => sum + i.quantity, 0);

    const taskResult = db.prepare(`INSERT INTO packing_tasks (name, status, total_items) VALUES (?, 'active', ?)`).run(taskName, totalQty);
    const taskId = taskResult.lastInsertRowid;

    const insertItem = db.prepare(`INSERT INTO packing_task_items (task_id, product_id, planned_qty, scanned_qty, requires_marking) VALUES (?, ?, ?, 0, ?)`);
    for (const item of items) {
      insertItem.run(taskId, item.product.id, item.quantity, item.product.requires_marking ? 1 : 0);
    }

    res.json({ success: true, taskId, created: items.length, totalQuantity: totalQty, notFound: notFound.length > 0 ? notFound : undefined });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Ошибка загрузки', message: error.message });
  }
});

// Создание задачи вручную
router.post('/tasks', async (req, res) => {
  try {
    const db = await getDb();
    const { name, items } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ error: 'Не указаны товары' });
    }

    const taskName = name || `Сборка ${new Date().toLocaleDateString('ru')} ${new Date().toLocaleTimeString('ru', {hour: '2-digit', minute: '2-digit'})}`;
    
    let totalQty = 0;
    const validItems = [];

    for (const item of items) {
      const product = db.prepare('SELECT * FROM products WHERE id = ?').get(item.productId);
      if (product) {
        validItems.push({ product, quantity: item.quantity || 1 });
        totalQty += item.quantity || 1;
      }
    }

    if (validItems.length === 0) {
      return res.status(400).json({ error: 'Не найдено товаров' });
    }

    const taskResult = db.prepare(`INSERT INTO packing_tasks (name, status, total_items) VALUES (?, 'active', ?)`).run(taskName, totalQty);
    const taskId = taskResult.lastInsertRowid;

    const insertItem = db.prepare(`INSERT INTO packing_task_items (task_id, product_id, planned_qty, scanned_qty, requires_marking) VALUES (?, ?, ?, 0, ?)`);
    for (const item of validItems) {
      insertItem.run(taskId, item.product.id, item.quantity, item.product.requires_marking ? 1 : 0);
    }

    res.json({ success: true, taskId, itemsCount: validItems.length, totalQuantity: totalQty });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Добавление товара в задачу
router.post('/tasks/:id/items', async (req, res) => {
  try {
    const db = await getDb();
    const taskId = req.params.id;
    const { productId, quantity = 1 } = req.body;

    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task || task.status !== 'active') {
      return res.status(400).json({ error: 'Задача не активна' });
    }

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
    if (!product) {
      return res.status(404).json({ error: 'Товар не найден' });
    }

    const existing = db.prepare('SELECT * FROM packing_task_items WHERE task_id = ? AND product_id = ?').get(taskId, productId);
    
    if (existing) {
      db.prepare('UPDATE packing_task_items SET planned_qty = planned_qty + ? WHERE id = ?').run(quantity, existing.id);
    } else {
      db.prepare(`INSERT INTO packing_task_items (task_id, product_id, planned_qty, scanned_qty, requires_marking) VALUES (?, ?, ?, 0, ?)`).run(taskId, productId, quantity, product.requires_marking ? 1 : 0);
    }

    db.prepare(`UPDATE packing_tasks SET total_items = (SELECT SUM(planned_qty) FROM packing_task_items WHERE task_id = ?) WHERE id = ?`).run(taskId, taskId);

    res.json({ success: true, product: product.name, quantity });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Сканирование товара
router.post('/tasks/:id/scan', async (req, res) => {
  try {
    const db = await getDb();
    const { barcode } = req.body;
    const taskId = req.params.id;

    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task || task.status !== 'active') {
      return res.status(400).json({ error: 'Задача не активна' });
    }

    const product = db.prepare('SELECT * FROM products WHERE barcode = ?').get(barcode);
    if (!product) {
      return res.status(404).json({ error: 'Товар не найден', barcode });
    }

    const taskItem = db.prepare(`SELECT * FROM packing_task_items WHERE task_id = ? AND product_id = ?`).get(taskId, product.id);

    if (!taskItem) {
      return res.status(400).json({ error: 'Товар не в задаче', product: product.name });
    }

    if (taskItem.scanned_qty >= taskItem.planned_qty) {
      return res.status(400).json({ error: 'Товар уже собран', product: product.name });
    }

    db.prepare(`UPDATE packing_task_items SET scanned_qty = scanned_qty + 1 WHERE id = ?`).run(taskItem.id);

    const updated = db.prepare(`SELECT * FROM packing_task_items WHERE id = ?`).get(taskItem.id);

    res.json({
      success: true,
      product: product.name,
      scanned: updated.scanned_qty,
      quantity: updated.planned_qty,
      complete: updated.scanned_qty >= updated.planned_qty
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Маршрутный лист
router.get('/tasks/:id/route-sheet', async (req, res) => {
  try {
    const db = await getDb();
    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(req.params.id);
    
    if (!task) {
      return res.status(404).json({ error: 'Задача не найдена' });
    }

    const items = db.prepare(`
      SELECT pti.*, p.name, p.barcode, p.article, p.stock, p.cell_address, p.image_url
      FROM packing_task_items pti
      JOIN products p ON p.id = pti.product_id
      WHERE pti.task_id = ?
      ORDER BY p.cell_address, p.name
    `).all(req.params.id);

    // Разделяем на доступные и недоступные
    const available = items.filter(i => (i.stock || 0) > 0);
    const noStock = items.filter(i => (i.stock || 0) <= 0);

    // Группируем по зонам
    const zones = {};
    for (const item of available) {
      const zone = item.cell_address ? item.cell_address.charAt(0).toUpperCase() : '—';
      if (!zones[zone]) zones[zone] = [];
      zones[zone].push({ ...item, qty_to_collect: Math.min(item.planned_qty, item.stock) });
    }

    res.json({
      task,
      zones,
      available: available.length,
      noStock,
      noStockCount: noStock.length,
      totalToCollect: available.reduce((s, i) => s + Math.min(i.planned_qty, i.stock || 0), 0)
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Завершение и создание отгрузки
router.post('/tasks/:id/complete', async (req, res) => {
  try {
    const db = await getDb();
    const taskId = req.params.id;
    const { createShipment = true } = req.body;

    const task = db.prepare('SELECT * FROM packing_tasks WHERE id = ?').get(taskId);
    if (!task || task.status !== 'active') {
      return res.status(400).json({ error: 'Задача не активна' });
    }

    const items = db.prepare(`
      SELECT pti.*, p.name, p.meta_href, p.price
      FROM packing_task_items pti
      JOIN products p ON p.id = pti.product_id
      WHERE pti.task_id = ? AND pti.scanned_qty > 0
    `).all(taskId);

    if (items.length === 0) {
      return res.status(400).json({ error: 'Нет собранных товаров' });
    }

    let shipmentId = null;
    let shipmentName = null;

    if (createShipment) {
      try {
        const moysklad = getMoySkladService();
        const store = await moysklad.getDefaultStore();
        const organization = await moysklad.getDefaultOrganization();

        const shipmentItems = items.map(item => ({
          quantity: item.scanned_qty,
          price: item.price || 0,
          productHref: item.meta_href
        }));

        const shipment = await moysklad.createDemand(shipmentItems, store, organization, `Сборка: ${task.name}`);
        shipmentId = shipment.id;
        shipmentName = shipment.name;
      } catch (msError) {
        console.error('MoySklad error:', msError.message);
      }
    }

    db.prepare(`UPDATE packing_tasks SET status = 'completed', completed_at = datetime('now'), shipment_id = ? WHERE id = ?`).run(shipmentId, taskId);

    res.json({ success: true, message: shipmentId ? `Отгрузка ${shipmentName} создана` : 'Задача завершена', shipmentId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Отмена задачи
router.post('/tasks/:id/cancel', async (req, res) => {
  try {
    const db = await getDb();
    db.prepare(`UPDATE packing_tasks SET status = 'cancelled' WHERE id = ? AND status = 'active'`).run(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Удаление товара
router.delete('/tasks/:id/items/:itemId', async (req, res) => {
  try {
    const db = await getDb();
    const { id: taskId, itemId } = req.params;

    db.prepare('DELETE FROM packing_task_items WHERE id = ? AND task_id = ?').run(itemId, taskId);
    db.prepare(`UPDATE packing_tasks SET total_items = (SELECT COALESCE(SUM(planned_qty), 0) FROM packing_task_items WHERE task_id = ?) WHERE id = ?`).run(taskId, taskId);

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
