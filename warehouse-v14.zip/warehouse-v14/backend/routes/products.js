import { Router } from 'express';
import { getDb, logAction } from '../database.js';
import { getMoySkladService } from '../services/moysklad.js';

const router = Router();

// Получение списка товаров
router.get('/', async (req, res) => {
  try {
    const db = await getDb();
    const { search, noBarcode, limit = 100, offset = 0 } = req.query;
    
    let sql = 'SELECT * FROM products WHERE 1=1';
    const params = [];

    if (search) {
      // Регистронезависимый поиск для кириллицы через LOWER
      const searchLower = search.toLowerCase();
      sql += ' AND (LOWER(name) LIKE ? OR LOWER(barcode) LIKE ? OR LOWER(sku) LIKE ? OR LOWER(article) LIKE ?)';
      const term = `%${searchLower}%`;
      params.push(term, term, term, term);
    }

    if (noBarcode === 'true') {
      sql += ' AND (barcode IS NULL OR barcode = "")';
    }

    sql += ' ORDER BY name LIMIT ? OFFSET ?';
    params.push(Number(limit), Number(offset));

    const products = db.prepare(sql).all(...params);
    
    const result = products.map(p => ({
      ...p,
      hasImage: !!p.image_url
    }));

    const countSql = 'SELECT COUNT(*) as total FROM products';
    const totalRow = db.prepare(countSql).get();

    res.json({ products: result, total: totalRow?.total || 0 });
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ error: err.message });
  }
});

// Получение товара по ID
router.get('/:id', async (req, res) => {
  try {
    const db = await getDb();
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Поиск по штрихкоду
router.get('/barcode/:barcode', async (req, res) => {
  try {
    const db = await getDb();
    const product = db.prepare('SELECT * FROM products WHERE barcode = ?').get(req.params.barcode);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Поиск по артикулу
router.get('/article/:article', async (req, res) => {
  try {
    const db = await getDb();
    const product = db.prepare('SELECT * FROM products WHERE article = ? OR sku = ?').get(req.params.article, req.params.article);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Синхронизация с МойСклад
router.post('/sync', async (req, res) => {
  try {
    const db = await getDb();
    const moysklad = getMoySkladService();
    
    db.prepare('UPDATE sync_status SET status = ? WHERE id = 1').run('syncing');
    await logAction('sync_started');

    // Получаем товары
    const products = await moysklad.getAllProducts();
    
    // Получаем остатки
    const stockData = await moysklad.getStock();
    const stockMap = new Map();
    for (const item of stockData) {
      if (item.meta?.href) {
        const id = item.meta.href.split('/').pop();
        stockMap.set(id, item.stock || 0);
      }
    }

    // Сохраняем в БД
    const insertStmt = db.prepare(`
      INSERT OR REPLACE INTO products (id, name, article, barcode, sku, price, stock, image_url, meta_href, requires_marking, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `);

    for (const product of products) {
      const id = product.id;
      const barcodes = product.barcodes || [];
      const barcode = barcodes.find(b => b.ean13)?.ean13 || 
                      barcodes.find(b => b.ean8)?.ean8 || 
                      barcodes.find(b => b.code128)?.code128 || '';
      
      // Получаем URL миниатюры изображения
      let imageUrl = null;
      if (product.images?.meta?.size > 0 && product.images?.rows?.length > 0) {
        const img = product.images.rows[0];
        imageUrl = img.miniature?.href || img.tiny?.href || null;
      }
      
      // Проверяем требуется ли маркировка (trackingType или признак в товаре)
      const requiresMarking = product.trackingType && product.trackingType !== 'NOT_TRACKED' ? 1 : 0;
      
      insertStmt.run(
        id,
        product.name || '',
        product.article || '',
        barcode || '',
        product.code || '',
        (product.salePrices?.[0]?.value || 0) / 100,
        stockMap.get(id) || 0,
        imageUrl || null,
        product.meta?.href || '',
        requiresMarking
      );
    }

    // Синхронизируем заказы поставщикам
    const orders = await moysklad.getPurchaseOrders();
    
    const insertOrder = db.prepare(`
      INSERT OR REPLACE INTO purchase_orders 
      (id, name, moment, supplier_name, total_items, meta_href, agent_meta, organization_meta, store_meta, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `);

    const deleteOrderItems = db.prepare('DELETE FROM purchase_order_items WHERE order_id = ?');
    const insertOrderItem = db.prepare(`
      INSERT INTO purchase_order_items (order_id, product_id, ordered_qty)
      VALUES (?, ?, ?)
    `);

    for (const order of orders) {
      const totalItems = order.positions?.meta?.size || 0;
      
      // Сохраняем meta как JSON строки для точного восстановления
      const agentMeta = order.agent?.meta ? JSON.stringify(order.agent.meta) : null;
      const organizationMeta = order.organization?.meta ? JSON.stringify(order.organization.meta) : null;
      const storeMeta = order.store?.meta ? JSON.stringify(order.store.meta) : null;
      
      insertOrder.run(
        order.id,
        order.name || '',
        order.moment || '',
        order.agent?.name || '',
        totalItems,
        order.meta?.href || '',
        agentMeta,
        organizationMeta,
        storeMeta
      );

      // Получаем позиции заказа
      if (totalItems > 0) {
        deleteOrderItems.run(order.id);
        const positions = await moysklad.getPurchaseOrderPositions(order.id);
        
        for (const pos of positions) {
          const productId = pos.assortment?.meta?.href?.split('/').pop();
          if (productId) {
            insertOrderItem.run(order.id, productId, pos.quantity || 0);
          }
        }
      }
    }

    // Обновляем статус
    db.prepare(`
      UPDATE sync_status 
      SET last_sync = datetime('now'), products_count = ?, orders_count = ?, status = 'success'
      WHERE id = 1
    `).run(products.length, orders.length);

    await logAction('sync_completed', 'products', null, { products: products.length, orders: orders.length });

    res.json({ 
      success: true, 
      productsCount: products.length,
      ordersCount: orders.length,
      message: `Синхронизировано: ${products.length} товаров, ${orders.length} заказов`
    });

  } catch (error) {
    const db = await getDb();
    db.prepare('UPDATE sync_status SET status = ? WHERE id = 1').run('error');
    await logAction('sync_failed', null, null, { error: error.message });
    console.error('Sync error:', error);
    res.status(500).json({ error: 'Sync failed', message: error.message });
  }
});

// Статус синхронизации
router.get('/sync/status', async (req, res) => {
  try {
    const db = await getDb();
    const status = db.prepare('SELECT * FROM sync_status WHERE id = 1').get();
    
    let connected = false;
    let connectionError = null;

    try {
      const moysklad = getMoySkladService();
      const check = await moysklad.checkConnection();
      connected = check.connected;
      connectionError = check.error;
    } catch (error) {
      connectionError = error.message;
    }

    res.json({ ...status, connected, connectionError });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
