import axios from 'axios';

const BASE_URL = 'https://api.moysklad.ru/api/remap/1.2';

class MoySkladService {
  constructor() {
    const token = process.env.MOYSKLAD_TOKEN;
    const login = process.env.MOYSKLAD_LOGIN;
    const password = process.env.MOYSKLAD_PASSWORD;
    
    let authHeader;
    
    if (token) {
      authHeader = `Bearer ${token}`;
    } else if (login && password) {
      const base64 = Buffer.from(`${login}:${password}`).toString('base64');
      authHeader = `Basic ${base64}`;
    } else {
      throw new Error('MOYSKLAD_TOKEN или MOYSKLAD_LOGIN + MOYSKLAD_PASSWORD не настроены');
    }
    
    this.client = axios.create({
      baseURL: BASE_URL,
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json',
        'Accept-Encoding': 'gzip'
      }
    });
  }

  async checkConnection() {
    try {
      const response = await this.client.get('/entity/employee', { params: { limit: 1 } });
      return { connected: true, user: response.data.rows[0]?.name };
    } catch (error) {
      return { connected: false, error: error.message };
    }
  }

  // Получение всех товаров с информацией о маркировке
  async getAllProducts() {
    const products = [];
    let offset = 0;
    const limit = 1000;

    while (true) {
      const response = await this.client.get('/entity/product', {
        params: {
          offset,
          limit,
          expand: 'images'
        }
      });

      products.push(...response.data.rows);

      if (response.data.rows.length < limit) break;
      offset += limit;
    }

    return products;
  }

  // Получение остатков
  async getStock() {
    const stock = [];
    let offset = 0;
    const limit = 1000;

    while (true) {
      const response = await this.client.get('/report/stock/all', {
        params: { offset, limit }
      });

      stock.push(...response.data.rows);

      if (response.data.rows.length < limit) break;
      offset += limit;
    }

    return stock;
  }

  // Получение заказов поставщикам
  async getPurchaseOrders() {
    const orders = [];
    let offset = 0;
    const limit = 100;

    while (true) {
      const response = await this.client.get('/entity/purchaseorder', {
        params: {
          offset,
          limit,
          expand: 'agent,positions',
          filter: 'applicable=true',
          order: 'moment,desc'
        }
      });

      orders.push(...response.data.rows);

      if (response.data.rows.length < limit) break;
      offset += limit;
      
      // Ограничиваем 500 заказами
      if (orders.length >= 500) break;
    }

    return orders;
  }

  // Получение позиций заказа поставщику
  async getPurchaseOrderPositions(orderId) {
    const response = await this.client.get(`/entity/purchaseorder/${orderId}/positions`, {
      params: { expand: 'assortment' }
    });
    return response.data.rows;
  }

  // Получение первого склада
  async getDefaultStore() {
    const response = await this.client.get('/entity/store', { params: { limit: 1 } });
    return response.data.rows[0];
  }

  // Получение первой организации
  async getDefaultOrganization() {
    const response = await this.client.get('/entity/organization', { params: { limit: 1 } });
    return response.data.rows[0];
  }

  // Создание отгрузки (demand)
  async createShipment(items, store, organization) {
    const positions = items.map(item => ({
      quantity: item.quantity,
      price: (item.price || 0) * 100,
      assortment: {
        meta: {
          href: item.productHref,
          type: 'product',
          mediaType: 'application/json'
        }
      }
    }));

    const response = await this.client.post('/entity/demand', {
      organization: {
        meta: {
          href: organization.meta.href,
          type: 'organization',
          mediaType: 'application/json'
        }
      },
      store: {
        meta: {
          href: store.meta.href,
          type: 'store',
          mediaType: 'application/json'
        }
      },
      positions
    });

    return response.data;
  }

  // Получение контрагента по умолчанию (первый поставщик)
  async getDefaultAgent() {
    const response = await this.client.get('/entity/counterparty', { 
      params: { limit: 1, filter: 'companyType=legal' } 
    });
    return response.data.rows[0];
  }

  // Создание приёмки (supply) на основе заказа поставщику
  async createSupply(purchaseOrder, items, store, organization, agent = null) {
    const positions = items.map(item => ({
      quantity: item.quantity,
      price: (item.price || 0) * 100,
      assortment: {
        meta: {
          href: item.productHref,
          type: 'product',
          mediaType: 'application/json'
        }
      }
    }));

    // Получаем контрагента
    let agentMeta = agent?.meta;
    
    if (purchaseOrder?.agent?.meta) {
      agentMeta = purchaseOrder.agent.meta;
    }
    
    if (!agentMeta) {
      // Получаем любого контрагента если не указан
      const defaultAgent = await this.getDefaultAgent();
      if (defaultAgent) {
        agentMeta = defaultAgent.meta;
      }
    }

    if (!agentMeta) {
      throw new Error('Не найден контрагент для приёмки');
    }

    const body = {
      organization: {
        meta: {
          href: organization.meta.href,
          type: 'organization',
          mediaType: 'application/json'
        }
      },
      store: {
        meta: {
          href: store.meta.href,
          type: 'store',
          mediaType: 'application/json'
        }
      },
      agent: {
        meta: agentMeta
      },
      positions
    };

    // Привязываем к заказу поставщику если есть
    if (purchaseOrder?.meta?.href) {
      body.purchaseOrder = {
        meta: {
          href: purchaseOrder.meta.href,
          type: 'purchaseorder',
          mediaType: 'application/json'
        }
      };
    }

    const response = await this.client.post('/entity/supply', body);
    return response.data;
  }

  // Создание оприходования (enter) для пересорта/излишков
  async createEnter(items, store, organization, description = '') {
    const positions = items.map(item => ({
      quantity: item.quantity,
      price: (item.price || 0) * 100,
      assortment: {
        meta: {
          href: item.productHref,
          type: 'product',
          mediaType: 'application/json'
        }
      }
    }));

    const response = await this.client.post('/entity/enter', {
      organization: {
        meta: {
          href: organization.meta.href,
          type: 'organization',
          mediaType: 'application/json'
        }
      },
      store: {
        meta: {
          href: store.meta.href,
          type: 'store',
          mediaType: 'application/json'
        }
      },
      description: description || 'Пересорт/излишки',
      positions
    });

    return response.data;
  }
  // Создание приёмки (supply) с прямым указанием meta данных
  async createSupplyDirect({ positions, agentMeta, organizationMeta, storeMeta, purchaseOrderMeta, description }) {
    const body = {
      organization: { meta: organizationMeta },
      store: { meta: storeMeta },
      agent: { meta: agentMeta },
      positions: positions.map(item => ({
        quantity: item.quantity,
        price: (item.price || 0) * 100,
        assortment: {
          meta: {
            href: item.productHref,
            type: 'product',
            mediaType: 'application/json'
          }
        }
      }))
    };

    // Добавляем комментарий если есть
    if (description) {
      body.description = description;
    }

    // Привязываем к заказу поставщику если есть
    if (purchaseOrderMeta) {
      body.purchaseOrder = { meta: purchaseOrderMeta };
    }

    const response = await this.client.post('/entity/supply', body);
    return response.data;
  }

  // Создание оприходования (enter) с прямым указанием meta данных
  async createEnterDirect({ positions, organizationMeta, storeMeta, description = '' }) {
    const body = {
      organization: { meta: organizationMeta },
      store: { meta: storeMeta },
      description: description || 'Оприходование',
      positions: positions.map(item => ({
        quantity: item.quantity,
        price: (item.price || 0) * 100,
        assortment: {
          meta: {
            href: item.productHref,
            type: 'product',
            mediaType: 'application/json'
          }
        }
      }))
    };

    const response = await this.client.post('/entity/enter', body);
    return response.data;
  }

  // Создание отгрузки (demand) - списание со склада
  async createDemand(items, store, organization, description = '') {
    const positions = items.map(item => ({
      quantity: item.quantity,
      price: (item.price || 0) * 100,
      assortment: {
        meta: {
          href: item.productHref,
          type: 'product',
          mediaType: 'application/json'
        }
      }
    }));

    // Получаем контрагента по умолчанию
    const agent = await this.getDefaultAgent();
    if (!agent) {
      throw new Error('Не найден контрагент для отгрузки');
    }

    const body = {
      organization: {
        meta: {
          href: organization.meta.href,
          type: 'organization',
          mediaType: 'application/json'
        }
      },
      store: {
        meta: {
          href: store.meta.href,
          type: 'store',
          mediaType: 'application/json'
        }
      },
      agent: {
        meta: agent.meta
      },
      description: description || 'Отгрузка со склада',
      positions
    };

    const response = await this.client.post('/entity/demand', body);
    return response.data;
  }

  // Получение контрагента по умолчанию
  async getDefaultAgent() {
    try {
      const response = await this.client.get('/entity/counterparty', {
        params: { limit: 1 }
      });
      return response.data.rows[0] || null;
    } catch (error) {
      console.error('Error getting default agent:', error.message);
      return null;
    }
  }
}

let instance = null;

export function getMoySkladService() {
  if (!instance) {
    instance = new MoySkladService();
  }
  return instance;
}

export default MoySkladService;
