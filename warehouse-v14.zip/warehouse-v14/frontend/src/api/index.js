import axios from 'axios';

const api = axios.create({ baseURL: '/api', timeout: 30000 });

export const getProducts = (params) => api.get('/products', { params });
export const syncProducts = () => api.post('/products/sync');
export const getSyncStatus = () => api.get('/products/sync/status');

export const getPackingTasks = () => api.get('/packing/tasks');
export const getPackingTask = (id) => api.get(`/packing/tasks/${id}`);
export const importExcel = (file, name) => {
  const formData = new FormData();
  formData.append('file', file);
  if (name) formData.append('name', name);
  return api.post('/packing/import', formData);
};
export const scanItem = (taskId, barcode, chestnyZnak, boxId) => 
  api.post(`/packing/tasks/${taskId}/scan`, { barcode, chestnyZnak, boxId });
export const createBox = (taskId) => api.post(`/packing/tasks/${taskId}/boxes`);
export const completePacking = (taskId) => api.post(`/packing/tasks/${taskId}/complete`);

export const getReceivingSessions = () => api.get('/receiving/sessions');
export const getReceivingSession = (id) => api.get(`/receiving/sessions/${id}`);
export const createReceivingSession = (name) => api.post('/receiving/sessions', { name });
export const addReceivingItem = (sessionId, productId, quantity) => 
  api.post(`/receiving/sessions/${sessionId}/items`, { productId, quantity });
export const removeReceivingItem = (sessionId, itemId) =>
  api.delete(`/receiving/sessions/${sessionId}/items/${itemId}`);
export const completeReceiving = (sessionId) => api.post(`/receiving/sessions/${sessionId}/complete`);

export default api;
